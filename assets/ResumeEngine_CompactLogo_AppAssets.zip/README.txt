Resume Engine compact logo asset pack

Files
- logo-compact.png: native transparent master extracted from the supplied compact card
- logo-compact-256.png: navigation and larger toolbar use
- logo-compact-128.png: compact navigation/sidebar use
- logo-compact-64.png: small toolbar use
- logo-compact.webp: lossless transparent WebP
- logo-compact-light-bg.png: 256 px PNG on a light app-compatible background

Treatment
- Caption and card border removed.
- Outer card background removed while enclosed light artwork was preserved.
- Transparent safe area added.
- Downscaled variants use high-quality Lanczos resampling.
- No upscaling or redrawing was applied.

Suggested placement
- Header/sidebar: 48 to 72 CSS pixels tall using the 128 or 256 px asset.
- Avoid using this detailed compact mark below 32 CSS pixels; use the dedicated favicon instead.
