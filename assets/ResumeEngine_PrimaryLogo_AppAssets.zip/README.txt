Resume Engine primary logo asset pack

Files
- logo-primary.png: native-resolution transparent PNG for landing/about screens
- logo-primary-480.png: responsive home-screen PNG
- logo-primary-320.png: compact header PNG
- logo-primary.webp: lossless transparent WebP for modern browsers

Recommended use
- Home/landing page: logo-primary.webp with logo-primary-480.png as PNG fallback
- App header: logo-primary-320.png, displayed around 160-220 CSS pixels wide
- Preserve aspect ratio. Do not stretch, recolor, or place on a very dark background.

Source treatment
- Transparent outer whitespace was trimmed.
- A 16-pixel transparent safe area was added.
- PNG files were losslessly compressed.
- No upscaling or artwork alteration was applied.
