from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def test_preferences_dates_navigation_contract():
 app=(ROOT/'frontend/src/App.tsx').read_text(); repo=(ROOT/'backend/app/library_repository.py').read_text(); phase=(ROOT/'backend/app/phase2l.py').read_text()
 assert 'preferred_page_length' in repo and 'section_sort_modes' in repo
 assert 'date_format="long"' in phase and 'display_date(row,date_format)' in phase
 assert (ROOT/'frontend/src/MonthYearField.tsx').exists()
 month=(ROOT/'frontend/src/MonthYearField.tsx').read_text(); assert 'Year only' in month and '03/2024' in month
 assert 'setTab("library")' not in app
 assert 'aria-disabled="true"' in app and 'Editing in the Library from the editor is coming soon.' in app
