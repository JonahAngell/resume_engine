
import React, { useCallback, useEffect, useRef, useState } from "react";
import FitIndicator, { Fit } from "./FitIndicator";
import ResumePreview from "./ResumePreview";
import { api } from "./api";
import { RESUME_ENGINE_BUILD, RESUME_ENGINE_VERSION } from "./app-version";
import { EditorHistory } from "./EditorHistory";
import StandaloneLibrary from "./StandaloneLibrary";
import { AppIcon } from "./AppIcon";
import MonthYearField from "./MonthYearField";

import primaryLogo from "./assets/logo-primary-480.png";
import compactLogo from "./assets/logo-compact.png";
import favicon from "./assets/favicon-256.png";

type Comp = {
  id: string;
  name: string;
  description: string;
  display_title: string;
  target_company: string;
  target_role: string;
  preferred_page_length: number;
  date_format: "year" | "numeric" | "short" | "long";
  section_sort_modes: Record<string, "automatic" | "manual">;
  summary_variant_id?: string | null;
  revision: number;
  archived_at?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
  autosaved_at?: string | null;
  resume: any;
};
type EditorKind =
  | "profile"
  | "summary"
  | "education"
  | "interest"
  | "tool-group"
  | "tool"
  | "project"
  | "employment"
  | "leadership"
  | "bullet"
  | "variant"
  | "custom-section"
  | "custom-entry"
  | null;
const blankProfile = {
  name: "",
  phone: "",
  email: "",
  linkedin_label: "",
  linkedin_url: "",
};
const blankSummary = { name: "", body: "" };
const blankEducation = {
  institution: "",
  college_school: "",
  location: "",
  degree_type: "",
  degree_major: "",
  graduation_year: "",
  graduation_month: "",
  display_date: "",
};
const blankInterest = { body: "" };
const blankToolGroup = { name: "" };
const blankTool = { name: "", group_id: "" };
const blankBullet = { parent_id: "", variant_name: "Default", body: "" };
const blankVariant = { bullet_id: "", name: "", body: "" };
const blankCustomSection = { title: "", layout: "list" };
const blankCustomEntry = {
  section_id: "",
  primary_text: "",
  secondary_text: "",
  location: "",
  date_label: "",
};
const blankHistorical = {
  name: "",
  subtitle: "",
  organization: "",
  location: "",
  title: "",
  date_label: "",
  start_year: "",
  start_month: "",
  end_year: "",
  end_month: "",
  is_current: false,
  bullets: [],
};

export default function App() {
  const [lib, setLib] = useState<any>(null);
  const [screen, setScreen] = useState<"home" | "editor" | "library">(() =>
    location.hash === "#library" ? "library" : "home",
  );
  const [homeSection, setHomeSection] = useState<"active" | "bin">("active");
  const [homeQuery, setHomeQuery] = useState("");
  const [homeView, setHomeView] = useState<"list" | "card">(() =>
    localStorage.getItem("resume-engine-home-view") === "card"
      ? "card"
      : "list",
  );
  const [comp, setComp] = useState<Comp | null>(null);
  const [toolbarRenameOpen, setToolbarRenameOpen] = useState(false);
  const [toolbarName, setToolbarName] = useState("");
  const [fit, setFit] = useState<Fit | null>(null);
  const [status, setStatus] = useState("Loading…");
  const [error, setError] = useState("");
  const [tab] = useState<"compose" | "history">("compose");
  const [editor, setEditor] = useState<EditorKind>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState<any>(null);
  const [formStatus, setFormStatus] = useState("");
  const [compositionFilter, setCompositionFilter] = useState("active");
  const [previewRevision, setPreviewRevision] = useState<any>(null);
  const [editorPercent, setEditorPercent] = useState(() => {
    const stored = Number(localStorage.getItem("resume-engine-editor-percent"));
    return stored >= 35 && stored <= 80 ? stored : 65;
  });
  const [editorCollapsed, setEditorCollapsed] = useState(
    () => localStorage.getItem("resume-engine-editor-collapsed") === "true",
  );
  const [previewCollapsed, setPreviewCollapsed] = useState(
    () => localStorage.getItem("resume-engine-preview-collapsed") === "true",
  );
  const [mobileWorkspace, setMobileWorkspace] = useState<"editor" | "preview">(
    () =>
      localStorage.getItem("resume-engine-mobile-workspace") === "preview"
        ? "preview"
        : "editor",
  );
  const [collapsedSections, setCollapsedSections] = useState<string[]>(() => {
    try {
      return JSON.parse(
        localStorage.getItem("resume-engine-collapsed-sections") || "[]",
      );
    } catch {
      return [];
    }
  });
  const [bulletPicker, setBulletPicker] = useState<any>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [zoom, setZoom] = useState(() => {
    const stored = Number(localStorage.getItem("resume-engine-preview-zoom"));
    return stored >= 50 && stored <= 150 ? stored : 100;
  });
  const splitterDragging = useRef(false);
  const compRef = useRef<Comp | null>(null);
  const historyRef = useRef(new EditorHistory());
  const sessionId = useRef(crypto.randomUUID());
  const [, refreshHistory] = useState(0);
  const timer = useRef<any>();
  useEffect(() => {
    compRef.current = comp;
    if (comp && !toolbarRenameOpen) setToolbarName(comp.name);
  }, [comp, toolbarRenameOpen]);
  useEffect(
    () => historyRef.current.subscribe(() => refreshHistory((x) => x + 1)),
    [],
  );
  useEffect(() => {
    if (comp) historyRef.current.begin(comp.id, sessionId.current);
  }, [comp?.id]);

  const loadLibrary = async () => {
    let next = await api<any>("/api/library");
    if (!next.compositions.length) {
      await api("/api/library/import-seed", {
        method: "POST",
        body: JSON.stringify({ seed_key: "jonah-resume-v1" }),
      });
      next = await api<any>("/api/library");
    }
    setLib(next);
    return next;
  };
  const loadComposition = async (id: string) => {
    const selected = lib?.compositions?.find?.((x: any) => x.id === id);
    const next = await api<Comp>(
      `/api/compositions/${id}${selected?.archived_at ? "?include_archived=true" : ""}`,
    );
    setComp(next);
    historyRef.current.begin(next.id, sessionId.current);
    setFit(null);
    return next;
  };
  const load = async () => {
    try {
      await loadLibrary();
      setStatus("Saved");
    } catch (e: any) {
      setError(e.message);
    }
  };
  useEffect(() => {
    const route = () => {
      if (location.hash === "#library") setScreen("library");
    };
    addEventListener("hashchange", route);
    return () => removeEventListener("hashchange", route);
  }, []);
  useEffect(() => {
    load();
    let icon = document.querySelector<HTMLLinkElement>("link[rel='icon']");
    if (!icon) {
      icon = document.createElement("link");
      icon.rel = "icon";
      document.head.appendChild(icon);
    }
    icon.href = favicon;
  }, []);

  const changed = (resume: any) => {
    if (!comp) return;
    setComp({ ...comp, resume });
    setFit(null);
    setStatus("Unsaved changes");
    clearTimeout(timer.current);
    const revision = comp.revision,
      id = comp.id;
    timer.current = setTimeout(async () => {
      try {
        setStatus("Saving…");
        setComp(
          await api<Comp>(`/api/compositions/${id}`, {
            method: "PUT",
            body: JSON.stringify({ revision, resume, source: "autosave" }),
          }),
        );
        setStatus("Saved");
      } catch (e: any) {
        setStatus(e.status === 409 ? "Conflict" : "Save failed");
        setError(e.message);
      }
    }, 700);
  };
  const mutation = async (
    work: () => Promise<any>,
    refreshComposition = true,
  ) => {
    try {
      setFormStatus("Saving…");
      await work();
      const next = await loadLibrary();
      if (refreshComposition && comp) await loadComposition(comp.id);
      setFormStatus("Saved");
      return next;
    } catch (e: any) {
      setFormStatus("Save failed");
      setError(e.message);
      throw e;
    }
  };
  const begin = (kind: EditorKind, item?: any) => {
    setEditor(kind);
    setEditingId(item?.id || null);
    setFormStatus("");
    if (kind === "profile") setDraft({ ...(lib.profile || blankProfile) });
    if (kind === "summary")
      setDraft(
        item ? { name: item.name, body: item.body } : { ...blankSummary },
      );
    if (kind === "education")
      setDraft(
        item
          ? {
              institution: item.institution,
              college_school: item.college_school || "",
              location: item.location || "",
              degree_type: item.degree_type || "",
              degree_major: item.degree_major || item.degree || "",
              graduation_year: item.graduation_year || "",
              graduation_month: item.graduation_month || "",
              display_date: item.display_date || item.graduation_date || "",
            }
          : { ...blankEducation },
      );
    if (kind === "interest")
      setDraft(item ? { body: item.body } : { ...blankInterest });
    if (kind === "custom-section")
      return (
        <div className="form-grid">
          {field("title", "Section title")}
          <label>
            Layout
            <select
              value={draft.layout}
              onChange={(e) => setDraft({ ...draft, layout: e.target.value })}
            >
              <option value="list">List</option>
              <option value="compact">Compact</option>
              <option value="dated">Dated</option>
              <option value="experience">Experience</option>
            </select>
          </label>
        </div>
      );
    if (kind === "custom-entry")
      return (
        <div className="form-grid">
          {field("primary_text", "Primary text")}
          {field("secondary_text", "Secondary text")}
          {field("location", "Location")}
          {field("date_label", "Date label")}
        </div>
      );
    if (kind === "tool-group")
      setDraft(item ? { name: item.name } : { ...blankToolGroup });
    if (kind === "tool")
      setDraft(
        item
          ? {
              name: item.name || "",
              group_id: item.group_id,
              groups: lib.tool_groups.filter((g: any) => !g.archived_at),
            }
          : {
              ...blankTool,
              group_id:
                lib.tool_groups.find((g: any) => !g.archived_at)?.id || "",
              groups: lib.tool_groups.filter((g: any) => !g.archived_at),
            },
      );
    if (kind === "bullet")
      setDraft(item ? { ...blankBullet, ...item } : { ...blankBullet });
    if (kind === "custom-section")
      setDraft(
        item
          ? { title: item.title, layout: item.layout }
          : { ...blankCustomSection },
      );
    if (kind === "custom-entry")
      setDraft(
        item ? { ...blankCustomEntry, ...item } : { ...blankCustomEntry },
      );
    if (kind === "variant")
      setDraft(
        item
          ? {
              bullet_id: item.bullet_id,
              name: item.variant_name || item.name || "",
              body: item.body || "",
            }
          : { ...blankVariant },
      );
    if (kind === "project" || kind === "employment" || kind === "leadership")
      setDraft(
        item
          ? { ...blankHistorical, ...item, bullets: item.bullets || [] }
          : { ...blankHistorical },
      );
  };
  const cancel = () => {
    setEditor(null);
    setEditingId(null);
    setDraft(null);
    setFormStatus("");
  };
  const saveDraft = async () => {
    if (!editor) return;
    const body = { ...draft };
    if (editor === "bullet") {
      await mutation(() =>
        api("/api/library/bullets", {
          method: "POST",
          body: JSON.stringify({
            parent_id: body.parent_id,
            variant_name: body.variant_name,
            body: body.body,
          }),
        }),
      );
      cancel();
      return;
    }
    if (editor === "custom-section" || editor === "custom-entry") {
      const family =
        editor === "custom-section" ? "custom-sections" : "custom-entries";
      await mutation(() =>
        api(`/api/library/${family}${editingId ? `/${editingId}` : ""}`, {
          method: editingId ? "PUT" : "POST",
          body: JSON.stringify(body),
        }),
      );
      cancel();
      return;
    }
    if (editor === "variant") {
      const path = editingId
        ? `/api/library/variants/${editingId}`
        : `/api/library/bullets/${body.bullet_id}/variants`;
      await mutation(() =>
        api(path, {
          method: editingId ? "PUT" : "POST",
          body: JSON.stringify({ name: body.name, body: body.body }),
        }),
      );
      cancel();
      return;
    }
    if (["education", "project", "employment", "leadership"].includes(editor)) {
      for (const name of editor === "education"
        ? ["graduation_year", "graduation_month"]
        : ["start_year", "start_month", "end_year", "end_month"])
        body[name] = body[name] ? Number(body[name]) : null;
    }
    if (["project", "employment", "leadership"].includes(editor)) {
      body.kind = editor;
      body.bullets = [];
    }
    const family =
      editor === "summary"
        ? "summaries"
        : editor === "interest"
          ? "interests"
          : editor === "tool-group"
            ? "tool-groups"
            : editor === "tool"
              ? "tools"
              : editor === "project" ||
                  editor === "employment" ||
                  editor === "leadership"
                ? "items"
                : "education";
    const path =
      editor === "profile"
        ? "/api/profile"
        : `/api/library/${family}${editingId ? `/${editingId}` : ""}`;
    await mutation(() =>
      api(path, {
        method: editor === "profile" || editingId ? "PUT" : "POST",
        body: JSON.stringify(body),
      }),
    );
    cancel();
  };
  const archive = async (table: string, id: string, archived: boolean) => {
    if (table === "tools" && !archived) {
      const restoreParent = confirm(
        "Restore this tool and restore its parent group if needed?",
      );
      if (!restoreParent) return;
      return mutation(() =>
        api(`/api/library/tools/${id}/restore-explicit`, {
          method: "POST",
          body: JSON.stringify({ outcome: "restore-parent" }),
        }),
      );
    }
    return mutation(() =>
      api(`/api/library/${table}/${id}/${archived ? "archive" : "restore"}`, {
        method: "POST",
      }),
    );
  };
  const move = async (
    kind: string,
    items: any[],
    index: number,
    direction: -1 | 1,
  ) => {
    const target = index + direction;
    if (target < 0 || target >= items.length) return;
    const reordered = [...items];
    [reordered[index], reordered[target]] = [
      reordered[target],
      reordered[index],
    ];
    await mutation(
      () =>
        api(`/api/library/${kind}/order`, {
          method: "PUT",
          body: JSON.stringify({ ids: reordered.map((x) => x.id) }),
        }),
      false,
    );
  };
  const chooseSummary = async (summary_variant_id: string) => {
    if (!comp) return;
    setStatus("Saving…");
    try {
      setComp(
        await api<Comp>(`/api/compositions/${comp.id}/summary`, {
          method: "PUT",
          body: JSON.stringify({
            revision: comp.revision,
            summary_variant_id: summary_variant_id || null,
          }),
        }),
      );
      setStatus("Saved");
    } catch (e: any) {
      setStatus(e.status === 409 ? "Conflict" : "Save failed");
      setError(e.message);
    }
  };
  const chooseInterest = async (item: any, included: boolean) => {
    if (!comp) return;
    setStatus("Saving…");
    try {
      setComp(
        await api<Comp>(`/api/compositions/${comp.id}/interests`, {
          method: "PUT",
          body: JSON.stringify({
            revision: comp.revision,
            interest_id: item.id,
            included,
          }),
        }),
      );
      setStatus("Saved");
    } catch (e: any) {
      setStatus(e.status === 409 ? "Conflict" : "Save failed");
      setError(e.message);
    }
  };
  const chooseLibraryItem = async (
    section: string,
    item: any,
    included: boolean,
  ) => {
    if (!comp) return;
    setStatus("Saving…");
    const endpoint =
      section === "tool_groups"
        ? "tool-groups"
        : section === "education"
          ? "education"
          : `historical/${section}`;
    try {
      setComp(
        await api<Comp>(`/api/compositions/${comp.id}/${endpoint}`, {
          method: "PUT",
          body: JSON.stringify({
            revision: comp.revision,
            item_id: item.id,
            included,
          }),
        }),
      );
      setStatus("Saved");
    } catch (e: any) {
      setStatus(e.status === 409 ? "Conflict" : "Save failed");
      setError(e.message);
    }
  };
  const included = (section: string, item: any) => {
    const rendered = comp?.resume?.[section] || [];
    if (section === "tool_groups")
      return rendered.some((x: any) => x.name === item.name);
    if (section === "projects")
      return rendered.some((x: any) => x.name === item.name);
    return rendered.some(
      (x: any) =>
        x.organization === item.organization && x.title === item.title,
    );
  };
  const chooseBulletVariant = async (bullet: any, variantId: string) => {
    if (!comp) return;
    setStatus("Saving…");
    try {
      setComp(
        await api<Comp>(`/api/compositions/${comp.id}/bullet-variant`, {
          method: "PUT",
          body: JSON.stringify({
            revision: comp.revision,
            bullet_id: bullet.id,
            variant_id: variantId,
          }),
        }),
      );
      await loadLibrary();
      setStatus("Saved");
    } catch (e: any) {
      setStatus(e.status === 409 ? "Conflict" : "Save failed");
      setError(e.message);
    }
  };
  const createBlankComposition = async () => {
    try {
      const next = await api<Comp>("/api/compositions", {
        method: "POST",
        body: JSON.stringify({}),
      });
      setComp(next);
      await loadLibrary();
      setPreviewRevision(null);
      setScreen("editor");
    } catch (e: any) {
      setError(e.message);
    }
  };
  const runHistoryAction = async (direction: "undo" | "redo") => {
    try {
      await historyRef.current[direction]();
      setStatus("Saved");
    } catch (e: any) {
      setStatus(e?.status === 409 ? "Conflict" : "Save failed");
      setError(
        e?.message ||
          `${direction} failed. Retry when synchronization is available.`,
      );
    }
  };
  const recordMetadataCommand = (
    before: any,
    after: any,
    preRevision: number,
  ) => {
    if (!compRef.current) return;
    const apply = async (value: any) => {
      const current = compRef.current!;
      const next = await api<Comp>(`/api/compositions/${current.id}/metadata`, {
        method: "PUT",
        body: JSON.stringify({ revision: current.revision, ...value }),
      });
      compRef.current = next;
      setComp(next);
      await loadLibrary();
    };
    historyRef.current.record({
      id: crypto.randomUUID(),
      label: "Resume details",
      compositionId: compRef.current.id,
      sessionId: sessionId.current,
      preRevision,
      identity: { compositionId: compRef.current.id, fieldGroup: "metadata" },
      undo: () => apply(before),
      redo: () => apply(after),
    });
  };
  const recordPreferenceCommand = (
    before: any,
    after: any,
    preRevision: number,
  ) => {
    if (!compRef.current) return;
    const apply = async (value: any) => {
      const current = compRef.current!;
      const next = await api<Comp>(
        `/api/compositions/${current.id}/preferences`,
        {
          method: "PUT",
          body: JSON.stringify({ revision: current.revision, ...value }),
        },
      );
      compRef.current = next;
      setComp(next);
    };
    historyRef.current.record({
      id: crypto.randomUUID(),
      label: "Resume preferences",
      compositionId: compRef.current.id,
      sessionId: sessionId.current,
      preRevision,
      identity: {
        compositionId: compRef.current.id,
        fieldGroup: "preferences",
      },
      undo: () => apply(before),
      redo: () => apply(after),
    });
  };
  const saveCompositionPreferences = async (preferences: any) => {
    if (!comp || comp.archived_at) return;
    if (
      preferences.preferred_page_length > 1 &&
      preferences.preferred_page_length !== comp.preferred_page_length &&
      !confirm(
        "Are you sure? Leading recruiters recommend keeping your resume to only one page for anyone with under 20 years of work experience.",
      )
    )
      return;
    const beforePreferences = {
      preferred_page_length: comp.preferred_page_length,
      date_format: comp.date_format,
      section_sort_modes: comp.section_sort_modes,
    };
    const preRevision = comp.revision;
    try {
      setStatus("Saving…");
      const savedPreferences = await api<Comp>(
        `/api/compositions/${comp.id}/preferences`,
        {
          method: "PUT",
          body: JSON.stringify({ revision: comp.revision, ...preferences }),
        },
      );
      setComp(savedPreferences);
      compRef.current = savedPreferences;
      recordPreferenceCommand(beforePreferences, preferences, preRevision);
      setStatus("Saved");
    } catch (e: any) {
      setStatus(e.status === 409 ? "Conflict" : "Save failed");
      setError(e.message);
    }
  };
  const saveCompositionMetadata = async (metadata: {
    name: string;
    description: string;
    display_title: string;
    target_company: string;
    target_role: string;
  }) => {
    if (!comp || comp.archived_at) return;
    const name = metadata.name.trim();
    if (!name) {
      setError("Internal name is required.");
      return;
    }
    const beforeMetadata = {
      name: comp.name,
      description: comp.description || "",
      display_title: comp.display_title || "",
      target_company: comp.target_company || "",
      target_role: comp.target_role || "",
    };
    const nextMetadata = { ...metadata, name };
    const preRevision = comp.revision;
    try {
      setStatus("Saving…");
      const savedMetadata = await api<Comp>(
        `/api/compositions/${comp.id}/metadata`,
        {
          method: "PUT",
          body: JSON.stringify({ revision: comp.revision, ...nextMetadata }),
        },
      );
      setComp(savedMetadata);
      compRef.current = savedMetadata;
      recordMetadataCommand(beforeMetadata, nextMetadata, preRevision);
      await loadLibrary();
      setStatus("Saved");
    } catch (e: any) {
      setStatus(e.status === 409 ? "Conflict" : "Save failed");
      setError(e.message);
    }
  };
  const lifecycleComposition = async (archiveIt: boolean) => {
    if (!comp) return;
    try {
      const next = await api<Comp>(
        `/api/compositions/${comp.id}/${archiveIt ? "archive" : "restore"}`,
        { method: "POST", body: JSON.stringify({ revision: comp.revision }) },
      );
      setComp(next);
      await loadLibrary();
      setStatus("Saved");
    } catch (e: any) {
      setStatus(e.status === 409 ? "Conflict" : "Save failed");
      setError(e.message);
    }
  };
  const reloadLatest = async () => {
    if (!comp) return;
    await loadComposition(comp.id);
    setStatus("Saved");
    setError("");
    setPreviewRevision(null);
  };
  const duplicate = async () => {
    const name = prompt("Name for duplicate", `${comp!.name} Copy`)?.trim();
    if (!name) return;
    try {
      setComp(
        await api<Comp>(`/api/compositions/${comp!.id}/duplicate`, {
          method: "POST",
          body: JSON.stringify({ name }),
        }),
      );
      await loadLibrary();
    } catch (e: any) {
      setError(e.message);
    }
  };
  const openComposition = async (id: string) => {
    try {
      await loadComposition(id);
      setPreviewRevision(null);
      setScreen("editor");
      setStatus("Saved");
    } catch (e: any) {
      setError(e.message);
    }
  };
  const renameFromHome = async (item: any) => {
    const name = prompt("Resume name", item.name)?.trim();
    if (!name || name === item.name) return;
    try {
      await api(`/api/compositions/${item.id}/metadata`, {
        method: "PUT",
        body: JSON.stringify({
          revision: item.revision,
          name,
          description: item.description || "",
          display_title: item.display_title || "",
          target_company: item.target_company || "",
          target_role: item.target_role || "",
        }),
      });
      await loadLibrary();
    } catch (e: any) {
      setError(e.message);
    }
  };
  const editDetailsFromHome = async (item: any) => {
    const name = prompt("Internal name", item.name)?.trim();
    if (!name) return;
    const display_title =
      prompt("Display title (optional)", item.display_title || "") ??
      (item.display_title || "");
    const target_company =
      prompt("Target company (optional)", item.target_company || "") ??
      (item.target_company || "");
    const target_role =
      prompt("Target role (optional)", item.target_role || "") ??
      (item.target_role || "");
    try {
      await api(`/api/compositions/${item.id}/metadata`, {
        method: "PUT",
        body: JSON.stringify({
          revision: item.revision,
          name,
          description: item.description || "",
          display_title,
          target_company,
          target_role,
        }),
      });
      await loadLibrary();
    } catch (e: any) {
      setError(e.message);
    }
  };
  const setArchivedFromHome = async (item: any, archived: boolean) => {
    const action = archived
      ? "move this resume to the Bin"
      : "restore this resume";
    if (!confirm(`Are you sure you want to ${action}?`)) return;
    try {
      await api(
        `/api/compositions/${item.id}/${archived ? "archive" : "restore"}`,
        {
          method: "POST",
          body: JSON.stringify({ revision: item.revision }),
        },
      );
      await loadLibrary();
    } catch (e: any) {
      setError(e.message);
    }
  };
  const changeHomeView = (view: "list" | "card") => {
    setHomeView(view);
    localStorage.setItem("resume-engine-home-view", view);
  };
  useEffect(() => {
    localStorage.setItem("resume-engine-editor-percent", String(editorPercent));
  }, [editorPercent]);
  useEffect(() => {
    localStorage.setItem(
      "resume-engine-editor-collapsed",
      String(editorCollapsed),
    );
  }, [editorCollapsed]);
  useEffect(() => {
    localStorage.setItem(
      "resume-engine-preview-collapsed",
      String(previewCollapsed),
    );
  }, [previewCollapsed]);
  useEffect(() => {
    localStorage.setItem("resume-engine-mobile-workspace", mobileWorkspace);
  }, [mobileWorkspace]);
  useEffect(() => {
    localStorage.setItem("resume-engine-preview-zoom", String(zoom));
  }, [zoom]);
  useEffect(() => {
    localStorage.setItem(
      "resume-engine-collapsed-sections",
      JSON.stringify(collapsedSections),
    );
  }, [collapsedSections]);
  useEffect(() => {
    const moveSplitter = (event: PointerEvent) => {
      if (!splitterDragging.current) return;
      const percent = Math.round((event.clientX / window.innerWidth) * 100);
      setEditorPercent(Math.min(80, Math.max(35, percent)));
    };
    const stopSplitter = () => {
      splitterDragging.current = false;
    };
    window.addEventListener("pointermove", moveSplitter);
    window.addEventListener("pointerup", stopSplitter);
    return () => {
      window.removeEventListener("pointermove", moveSplitter);
      window.removeEventListener("pointerup", stopSplitter);
    };
  }, []);

  const openBulletPicker = (target: any, replacement?: any) => {
    setBulletPicker({ target, replacement: replacement || null });
  };
  const closeBulletPicker = () => setBulletPicker(null);

  const saveNow = async () => {
    if (!comp || comp.archived_at || status === "Saving…") return;
    clearTimeout(timer.current);
    try {
      setStatus("Saving…");
      setComp(
        await api<Comp>(`/api/compositions/${comp.id}`, {
          method: "PUT",
          body: JSON.stringify({
            revision: comp.revision,
            resume: comp.resume,
            source: "manual",
          }),
        }),
      );
      setStatus("Saved");
    } catch (e: any) {
      setStatus(e.status === 409 ? "Conflict" : "Save failed");
      setError(e.message);
    }
  };
  const exportPdf = async () => {
    if (!comp || !fit?.fits) return;
    const r = await fetch(
      `/api/compositions/${comp.id}/export/pdf?revision=${comp.revision}`,
      { method: "POST" },
    );
    if (!r.ok) {
      setError("Export failed");
      return;
    }
    const a = document.createElement("a");
    a.href = URL.createObjectURL(await r.blob());
    a.download = "resume.pdf";
    a.click();
    URL.revokeObjectURL(a.href);
  };
  const toggleFullscreen = async () => {
    const element = document.querySelector<HTMLElement>(".preview-workspace");
    if (!element) return;
    if (document.fullscreenElement) await document.exitFullscreen();
    else await element.requestFullscreen();
  };
  const onFit = useCallback((x: Fit) => {
    setFit(x);
    setCurrentPage((page) =>
      Math.min(Math.max(1, page), x.actualPageCount || 1),
    );
  }, []);
  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target?.closest('[role="dialog"], [data-assistive-editor="true"]'))
        return;
      if (target?.matches('input, textarea, [contenteditable="true"]')) return;
      if (
        !(event.ctrlKey || event.metaKey) ||
        event.altKey ||
        event.key.toLowerCase() !== "z"
      )
        return;
      if (status === "Conflict") return;
      event.preventDefault();
      runHistoryAction(event.shiftKey ? "redo" : "undo");
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [status]);
  useEffect(() => {
    const handler = (event: BeforeUnloadEvent) => {
      if (
        ["Unsaved changes", "Saving…", "Conflict", "Save failed"].includes(
          status,
        )
      ) {
        event.preventDefault();
        event.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [status]);

  if (!lib) return <main className="loading">{error || "Loading…"}</main>;
  if (screen === "library")
    return (
      <StandaloneLibrary
        lib={lib}
        reloadLibrary={loadLibrary}
        onHome={() => {
          history.pushState(null, "", location.pathname);
          setHomeSection("active");
          setScreen("home");
        }}
        onBin={() => {
          history.pushState(null, "", location.pathname);
          setHomeSection("bin");
          setScreen("home");
        }}
        onOpenResume={async (id: string, usage?: any) => {
          if (usage)
            sessionStorage.setItem(
              "resume-engine-usage-target",
              JSON.stringify(usage),
            );
          await openComposition(id);
        }}
      />
    );
  if (screen === "home")
    return (
      <HomeScreen
        lib={lib}
        error={error}
        dismissError={() => setError("")}
        section={homeSection}
        setSection={setHomeSection}
        query={homeQuery}
        setQuery={setHomeQuery}
        view={homeView}
        setView={changeHomeView}
        createResume={createBlankComposition}
        openResume={openComposition}
        renameResume={renameFromHome}
        editDetails={editDetailsFromHome}
        setArchived={setArchivedFromHome}
        openLibrary={() => {
          location.hash = "library";
          setScreen("library");
        }}
      />
    );
  if (!comp) {
    setScreen("home");
    return null;
  }
  const activeSummaries = lib.summary_variants.filter(
    (x: any) => !x.archived_at,
  );
  return (
    <main className="editing-shell">
      <header className="editing-topbar">
        <div className="editing-brand">
          <img src={compactLogo} alt="" />
          <span>
            Resume <strong>Engine</strong>
          </span>
        </div>
        <div className="editing-document-name">
          {toolbarRenameOpen ? (
            <form
              className="toolbar-rename-form"
              onSubmit={async (event) => {
                event.preventDefault();
                const name = toolbarName.trim();
                if (!name || name === comp.name) {
                  setToolbarName(comp.name);
                  setToolbarRenameOpen(false);
                  return;
                }
                await saveCompositionMetadata({
                  name,
                  description: comp.description || "",
                  display_title: comp.display_title || "",
                  target_company: comp.target_company || "",
                  target_role: comp.target_role || "",
                });
                setToolbarRenameOpen(false);
              }}
            >
              <label className="sr-only" htmlFor="toolbar-resume-name">
                Resume name
              </label>
              <input
                id="toolbar-resume-name"
                value={toolbarName}
                maxLength={120}
                autoFocus
                onChange={(event) => setToolbarName(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Escape") {
                    setToolbarName(comp.name);
                    setToolbarRenameOpen(false);
                  }
                }}
              />
              <button type="submit" aria-label="Save resume name">
                Save
              </button>
              <button
                type="button"
                aria-label="Cancel resume rename"
                onClick={() => {
                  setToolbarName(comp.name);
                  setToolbarRenameOpen(false);
                }}
              >
                Cancel
              </button>
            </form>
          ) : (
            <button
              className="toolbar-rename-trigger"
              title="Rename resume"
              aria-label={`Rename ${comp.name}`}
              onClick={() => {
                setToolbarName(comp.name);
                setToolbarRenameOpen(true);
              }}
            >
              <span>{comp.name}</span>
              <span aria-hidden="true">✎</span>
            </button>
          )}
        </div>
        <div className="editing-actions">
          <span
            className={`topbar-status ${status.toLowerCase().replaceAll(" ", "-")}`}
            aria-live="polite"
          >
            {status}
          </span>
          <button onClick={() => setScreen("home")}>
            <AppIcon name="home" />
            <span className="action-label">Home</span>
          </button>
          <button
            onClick={() => {
              location.hash = "library";
              setScreen("library");
            }}
          >
            <AppIcon name="library" />
            <span className="action-label">Library</span>
          </button>
          <button
            onClick={saveNow}
            disabled={!!comp.archived_at || status === "Saving…"}
          >
            <AppIcon name="document" />
            <span className="action-label">Save</span>
          </button>
          <button
            onClick={() => runHistoryAction("undo")}
            disabled={
              !historyRef.current.snapshot.canUndo || status === "Conflict"
            }
            aria-busy={historyRef.current.snapshot.busy}
            aria-keyshortcuts="Control+Z Meta+Z"
            title="Undo last committed editor command"
          >
            <span aria-hidden="true">↶</span>
            <span className="action-label">Undo</span>
          </button>
          <button
            onClick={() => runHistoryAction("redo")}
            disabled={
              !historyRef.current.snapshot.canRedo || status === "Conflict"
            }
            aria-busy={historyRef.current.snapshot.busy}
            aria-keyshortcuts="Control+Shift+Z Meta+Shift+Z Control+Y"
            title="Redo last undone editor command"
          >
            <span aria-hidden="true">↷</span>
            <span className="action-label">Redo</span>
          </button>
          <button
            className="export-action"
            disabled={!fit?.fits}
            onClick={exportPdf}
          >
            <span aria-hidden="true">⇩</span>
            <span className="action-label">Export PDF</span>
          </button>
        </div>
      </header>
      <div
        className="mobile-workspace-toggle"
        role="group"
        aria-label="Workspace"
      >
        <button
          aria-pressed={mobileWorkspace === "editor"}
          onClick={() => setMobileWorkspace("editor")}
        >
          Editor
        </button>
        <button
          aria-pressed={mobileWorkspace === "preview"}
          onClick={() => setMobileWorkspace("preview")}
        >
          Live View
        </button>
      </div>
      <div
        className={`workspace mobile-${mobileWorkspace}`}
        style={{
          gridTemplateColumns: editorCollapsed
            ? "0 0 1fr"
            : previewCollapsed
              ? "1fr 0 0"
              : `${editorPercent}fr 10px ${100 - editorPercent}fr`,
        }}
      >
        {editorCollapsed ? (
          <button
            className="restore-pane restore-editor"
            onClick={() => setEditorCollapsed(false)}
          >
            Show editor
          </button>
        ) : (
          <aside className="editor" aria-label="Resume editor">
            <header className="editing-content-header">
              <div>
                <h1>Edit Resume</h1>
                <p>
                  Manage your content, organize sections, and tailor your
                  resume.
                </p>
                <span className="version-marker sr-only">
                  {RESUME_ENGINE_VERSION} Build {RESUME_ENGINE_BUILD}
                </span>
              </div>
              <button
                className="editor-collapse-action"
                aria-label="Collapse editor pane"
                onClick={() => setEditorCollapsed(true)}
              >
                ×
              </button>
            </header>
            {error && (
              <div role="alert" className="error">
                {error}
                <button onClick={() => setError("")}>Dismiss</button>
              </div>
            )}
            {tab === "compose" && (
              <>
                <ResumeDetails
                  comp={comp}
                  save={saveCompositionMetadata}
                  savePreferences={saveCompositionPreferences}
                  status={status}
                />
                <div
                  className={`save-status ${status.toLowerCase().replaceAll(" ", "-")}`}
                >
                  {status}
                </div>
                {status === "Conflict" && (
                  <div className="conflict-recovery" role="alert">
                    Unsaved local changes were not written.{" "}
                    <button onClick={reloadLatest}>
                      Reload latest composition
                    </button>
                  </div>
                )}
                <FitIndicator fit={fit} />
                <SectionsPanel
                  comp={comp}
                  lib={lib}
                  setComp={setComp}
                  setStatus={setStatus}
                  setError={setError}
                  collapsed={collapsedSections}
                  setCollapsed={setCollapsedSections}
                  begin={begin}
                  saveCompositionPreferences={saveCompositionPreferences}
                  chooseSummary={chooseSummary}
                  chooseInterest={chooseInterest}
                  chooseLibraryItem={chooseLibraryItem}
                  included={included}
                  chooseBulletVariant={chooseBulletVariant}
                  openBulletPicker={openBulletPicker}
                />
              </>
            )}
            {tab === "history" && (
              <History
                comp={comp}
                reload={() => loadComposition(comp.id)}
                preview={setPreviewRevision}
                clearPreview={() => setPreviewRevision(null)}
              />
            )}
          </aside>
        )}
        {!editorCollapsed && !previewCollapsed && (
          <div
            className="workspace-splitter"
            role="separator"
            aria-label="Resize editor and preview panes"
            aria-orientation="vertical"
            aria-valuemin={35}
            aria-valuemax={80}
            aria-valuenow={editorPercent}
            tabIndex={0}
            onPointerDown={(event) => {
              splitterDragging.current = true;
              event.currentTarget.setPointerCapture(event.pointerId);
            }}
            onKeyDown={(event) => {
              if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
                event.preventDefault();
                setEditorPercent((value) =>
                  Math.min(
                    80,
                    Math.max(35, value + (event.key === "ArrowRight" ? 2 : -2)),
                  ),
                );
              }
            }}
          >
            <span aria-hidden="true">⋮</span>
          </div>
        )}
        {previewCollapsed ? (
          <button
            className="restore-pane restore-preview"
            onClick={() => setPreviewCollapsed(false)}
          >
            Show preview
          </button>
        ) : (
          <section
            className="stage preview-workspace"
            aria-label="Live resume preview"
          >
            <div className="preview-toolbar">
              <button
                onClick={() => setPreviewCollapsed(true)}
                aria-label="Collapse preview pane"
              >
                ›
              </button>
              <button
                aria-label="Previous Page"
                disabled={currentPage <= 1}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              >
                ‹
              </button>
              <output aria-label="Current page and total pages">
                Page {currentPage} / {fit?.actualPageCount || 1}
              </output>
              <button
                aria-label="Next Page"
                disabled={currentPage >= (fit?.actualPageCount || 1)}
                onClick={() =>
                  setCurrentPage((p) =>
                    Math.min(fit?.actualPageCount || 1, p + 1),
                  )
                }
              >
                ›
              </button>
              <span className="preview-toolbar-spacer" />
              <button
                onClick={() => setZoom((value) => Math.max(50, value - 10))}
                aria-label="Zoom out"
              >
                −
              </button>
              <output aria-label="Preview zoom">{zoom}%</output>
              <button
                onClick={() => setZoom((value) => Math.min(150, value + 10))}
                aria-label="Zoom in"
              >
                +
              </button>
              <button onClick={toggleFullscreen} aria-label="Expand preview">
                ⛶
              </button>
            </div>
            <div
              className="preview-canvas"
              style={{ "--preview-zoom": zoom / 100 } as React.CSSProperties}
            >
              {previewRevision && (
                <div className="revision-banner">
                  Previewing revision {previewRevision.revision} (read-only){" "}
                  <button onClick={() => setPreviewRevision(null)}>
                    Return to current
                  </button>
                </div>
              )}
              <ResumePreview
                compositionId={comp.id}
                revision={comp.revision}
                preferredPageCount={comp.preferred_page_length || 1}
                currentPage={currentPage}
                onFit={onFit}
              />
            </div>
          </section>
        )}
      </div>
    </main>
  );
}

function ResumeDetails({ comp, save, savePreferences, status }: any) {
  const [collapsed, setCollapsed] = useState(false);
  const [draft, setDraft] = useState({
    name: comp.name,
    description: comp.description || "",
    display_title: comp.display_title || "",
    target_company: comp.target_company || "",
    target_role: comp.target_role || "",
  });
  useEffect(() => {
    setDraft({
      name: comp.name,
      description: comp.description || "",
      display_title: comp.display_title || "",
      target_company: comp.target_company || "",
      target_role: comp.target_role || "",
    });
  }, [comp.id, comp.revision]);
  const field = (key: string, label: string, required = false) => (
    <label>
      {label}
      {required ? " *" : ""}
      <input
        value={draft[key as keyof typeof draft]}
        required={required}
        maxLength={key === "name" ? 120 : 200}
        onChange={(event) => setDraft({ ...draft, [key]: event.target.value })}
      />
    </label>
  );
  return (
    <section
      className={`resume-details editor-section ${collapsed ? "collapsed" : "expanded"}`}
      aria-labelledby="resume-details-title"
    >
      <div className="section-heading resume-details-heading">
        <h2 id="resume-details-title">
          <AppIcon name="details" /> Resume Details
        </h2>
        <button
          className="section-chevron"
          aria-expanded={!collapsed}
          aria-controls="resume-details-body"
          aria-label={`${collapsed ? "Expand" : "Collapse"} Resume Details`}
          onClick={() => setCollapsed((value) => !value)}
        >
          <span aria-hidden="true">↓</span>
        </button>
      </div>
      {!collapsed && (
        <div id="resume-details-body" className="resume-details-body">
          <div className="form-grid">
            {field("name", "Internal name", true)}
            {field("display_title", "Display title")}
            {field("target_company", "Target company")}
            {field("target_role", "Target role")}
          </div>
          <small>
            Display title and target details are planning metadata and are not
            printed on the resume.
          </small>
          <fieldset className="composition-preferences">
            <legend>Resume preferences</legend>
            <label>
              Preferred page length
              <select
                value={comp.preferred_page_length || 1}
                onChange={(e) =>
                  savePreferences({
                    preferred_page_length: Number(e.target.value),
                    date_format: comp.date_format || "long",
                    section_sort_modes: comp.section_sort_modes || {},
                  })
                }
              >
                <option value={1}>1 page</option>
                <option value={2}>2 pages</option>
                <option value={3}>3 pages</option>
              </select>
            </label>
            <label>
              Date format{" "}
              <small aria-live="polite">
                Example:{" "}
                {comp.date_format === "year"
                  ? "2026"
                  : comp.date_format === "numeric"
                    ? "10/2026"
                    : comp.date_format === "short"
                      ? "Oct 2026"
                      : "October 2026"}
              </small>
              <select
                value={comp.date_format || "long"}
                onChange={(e) =>
                  savePreferences({
                    preferred_page_length: comp.preferred_page_length || 1,
                    date_format: e.target.value,
                    section_sort_modes: comp.section_sort_modes || {},
                  })
                }
              >
                <option value="year">Year only</option>
                <option value="numeric">Numeric month/year</option>
                <option value="short">Short month/year</option>
                <option value="long">Long month/year</option>
              </select>
            </label>
          </fieldset>
          <div className="resume-details-actions">
            <button
              className="primary"
              disabled={!!comp.archived_at || status === "Saving…"}
              onClick={() => save(draft)}
            >
              Save details
            </button>
          </div>
        </div>
      )}
    </section>
  );
}

function HomeScreen({
  lib,
  error,
  dismissError,
  section,
  setSection,
  query,
  setQuery,
  view,
  setView,
  createResume,
  openResume,
  renameResume,
  editDetails,
  setArchived,
  openLibrary,
}: any) {
  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const archived = section === "bin";
  const rows = (lib.compositions || []).filter(
    (item: any) =>
      Boolean(item.archived_at) === archived &&
      [
        item.name,
        item.display_title,
        item.target_company,
        item.target_role,
      ].some((value: any) =>
        (value || "").toLowerCase().includes(query.trim().toLowerCase()),
      ),
  );
  const modified = (item: any) =>
    item.autosaved_at || item.updated_at || item.created_at;
  const formatDate = (value: string | null) =>
    value
      ? new Intl.DateTimeFormat(undefined, {
          dateStyle: "medium",
          timeStyle: "short",
        }).format(new Date(value))
      : "Unavailable";
  const menu = (item: any) => (
    <div className="resume-menu-wrap">
      <button
        className="icon-button"
        aria-label={`Actions for ${item.name}`}
        aria-haspopup="menu"
        aria-expanded={openMenu === item.id}
        onClick={(event) => {
          event.stopPropagation();
          setOpenMenu(openMenu === item.id ? null : item.id);
        }}
      >
        ⋯
      </button>
      {openMenu === item.id && (
        <div className="resume-menu" role="menu">
          {!archived && (
            <button
              role="menuitem"
              onClick={() => {
                setOpenMenu(null);
                renameResume(item);
              }}
            >
              Rename
            </button>
          )}
          {!archived && (
            <button
              role="menuitem"
              onClick={() => {
                setOpenMenu(null);
                editDetails(item);
              }}
            >
              Edit details
            </button>
          )}
          <button
            role="menuitem"
            className={archived ? "" : "danger-text"}
            onClick={() => {
              setOpenMenu(null);
              setArchived(item, !archived);
            }}
          >
            {archived ? "Restore" : "Move to Bin"}
          </button>
        </div>
      )}
    </div>
  );
  return (
    <main className="home-shell" onClick={() => openMenu && setOpenMenu(null)}>
      <aside className="home-rail" aria-label="Primary navigation">
        <img className="rail-logo" src={compactLogo} alt="Resume Engine" />
        <button
          className={section === "active" ? "rail-link active" : "rail-link"}
          onClick={() => setSection("active")}
        >
          <AppIcon name="home" />
          Home
        </button>
        <button className="rail-link" onClick={openLibrary}>
          <AppIcon name="library" />
          Library
        </button>
        <button
          className={section === "bin" ? "rail-link active" : "rail-link"}
          onClick={() => setSection("bin")}
        >
          <AppIcon name="bin" />
          Bin
        </button>
      </aside>
      <section className="home-content">
        {error && (
          <div role="alert" className="error home-error">
            {error}
            <button onClick={dismissError}>Dismiss</button>
          </div>
        )}
        <header className="home-hero">
          <img src={primaryLogo} alt="Resume Engine" className="home-logo" />
          <h1>Resume Engine</h1>
          <p>A Really Useful tool for completing job applications</p>
          {section === "active" && (
            <div className="hero-actions">
              <button className="primary-action" onClick={createResume}>
                + New Resume
              </button>
              <span className="tooltip-wrap">
                <button disabled aria-describedby="import-help">
                  Import Existing Resume
                </button>
                <span id="import-help" role="tooltip">
                  Import from an existing resume is coming soon.
                </span>
              </span>
            </div>
          )}
        </header>
        <section
          className="resume-library"
          aria-labelledby="resume-library-title"
        >
          <div className="library-toolbar">
            <label className="resume-search">
              <span aria-hidden="true">⌕</span>
              <span className="sr-only">Search resumes</span>
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search your resumes…"
              />
            </label>
            <div className="view-toggle" aria-label="Resume view">
              <button
                aria-pressed={view === "list"}
                onClick={() => setView("list")}
              >
                ☷ List View
              </button>
              <button
                aria-pressed={view === "card"}
                onClick={() => setView("card")}
              >
                ▦ Card View
              </button>
            </div>
          </div>
          <div className="library-title-row">
            <h2 id="resume-library-title">
              {archived ? "Bin" : "My Resumes"} ({rows.length})
            </h2>
          </div>
          {rows.length === 0 ? (
            <div className="empty-state">
              <strong>
                {query
                  ? "No matching resumes"
                  : archived
                    ? "The Bin is empty"
                    : "No resumes yet"}
              </strong>
              <span>
                {query
                  ? "Try a different search."
                  : archived
                    ? "Resumes moved to the Bin will appear here."
                    : "Create a new resume to get started."}
              </span>
            </div>
          ) : view === "list" ? (
            <div
              className="resume-table"
              role="table"
              aria-label={archived ? "Deleted resumes" : "Active resumes"}
            >
              <div className="resume-table-head" role="row">
                <span role="columnheader">Name</span>
                <span role="columnheader">Target Company</span>
                <span role="columnheader">Target Role</span>
                <span role="columnheader">Last Modified</span>
                <span aria-hidden="true" />
              </div>
              {rows.map((item: any) => (
                <div className="resume-table-row" role="row" key={item.id}>
                  <button
                    className="resume-name"
                    disabled={archived}
                    onClick={() => openResume(item.id)}
                    role="cell"
                  >
                    <AppIcon name="document" aria-hidden="true" />{" "}
                    <span>{item.name}</span>
                  </button>
                  <span
                    role="cell"
                    className={!item.target_company ? "placeholder-value" : ""}
                  >
                    {item.target_company || "—"}
                  </span>
                  <span
                    role="cell"
                    className={!item.target_role ? "placeholder-value" : ""}
                  >
                    {item.target_role || "—"}
                  </span>
                  <span role="cell">{formatDate(modified(item))}</span>
                  <span role="cell">{menu(item)}</span>
                </div>
              ))}
            </div>
          ) : (
            <div className="resume-card-grid">
              {rows.map((item: any) => (
                <article className="resume-card" key={item.id}>
                  <div className="resume-card-top">
                    <span className="resume-card-icon" aria-hidden="true">
                      <AppIcon name="document" />
                    </span>
                    {menu(item)}
                  </div>
                  <button
                    className="card-open"
                    disabled={archived}
                    onClick={() => openResume(item.id)}
                  >
                    <strong>{item.name}</strong>
                  </button>
                  <dl>
                    <div>
                      <dt>Target Company</dt>
                      <dd>{item.target_company || "—"}</dd>
                    </div>
                    <div>
                      <dt>Target Role</dt>
                      <dd>{item.target_role || "—"}</dd>
                    </div>
                  </dl>
                  <small>Last modified {formatDate(modified(item))}</small>
                </article>
              ))}
            </div>
          )}
        </section>
      </section>
    </main>
  );
}

function Library({
  lib,
  editor,
  draft,
  setDraft,
  editingId,
  formStatus,
  begin,
  cancel,
  saveDraft,
  archive,
  move,
  duplicateSummary,
  mutation,
}: any) {
  if (editor)
    return (
      <section>
        <h2>
          {editingId ? "Edit" : editor === "profile" ? "Edit" : "Create"}{" "}
          {editor}
        </h2>
        <LibraryForm kind={editor} draft={draft} setDraft={setDraft} />
        <div className="form-actions">
          <button className="primary" onClick={saveDraft}>
            Save
          </button>
          <button onClick={cancel}>Cancel</button>
          <span>{formStatus}</span>
        </div>
      </section>
    );
  return (
    <>
      <LibrarySearch />
      <section className="editor-section">
        <div className="section-heading">
          <h2>Profile</h2>
          <button onClick={() => begin("profile")}>Edit profile</button>
        </div>
        <p>
          {lib.profile?.name}
          <br />
          {lib.profile?.email}
        </p>
      </section>
      <RecordList
        title="Summary variants"
        kind="summary"
        orderKind="summaries"
        table="summary_variants"
        items={lib.summary_variants}
        label={(x: any) => x.name}
        {...{ begin, archive, move }}
        extra={(x: any) => (
          <button
            type="button"
            aria-label="Duplicate and edit as new variant"
            title="Duplicate and edit as new variant"
            onClick={() => duplicateSummary(x.id)}
          >
            Duplicate
          </button>
        )}
      />
      <RecordList
        title="Education"
        kind="education"
        orderKind="education"
        table="education_items"
        items={lib.education}
        label={(x: any) => x.institution}
        {...{ begin, archive, move }}
      />
      <ToolGroupsEditor lib={lib} begin={begin} archive={archive} move={move} />
      <RecordList
        title="Projects"
        kind="project"
        orderKind="historical/project"
        table="content_items"
        items={lib.projects}
        label={(x: any) => x.name}
        {...{ begin, archive, move }}
        extra={(x: any) => (
          <BulletsEditor item={x} lib={lib} begin={begin} mutation={mutation} />
        )}
      />
      <RecordList
        title="Work experience"
        kind="employment"
        orderKind="historical/employment"
        table="content_items"
        items={lib.employment}
        label={(x: any) => `${x.organization} — ${x.title}`}
        {...{ begin, archive, move }}
        extra={(x: any) => (
          <BulletsEditor item={x} lib={lib} begin={begin} mutation={mutation} />
        )}
      />
      <RecordList
        title="Leadership"
        kind="leadership"
        orderKind="historical/leadership"
        table="content_items"
        items={lib.leadership}
        label={(x: any) => `${x.organization} — ${x.title}`}
        {...{ begin, archive, move }}
        extra={(x: any) => (
          <BulletsEditor item={x} lib={lib} begin={begin} mutation={mutation} />
        )}
      />
      <CustomSectionsEditor lib={lib} begin={begin} mutation={mutation} />
      <RecordList
        title="Interests"
        kind="interest"
        orderKind="interests"
        table="interests"
        items={lib.interests}
        label={(x: any) => x.body}
        {...{ begin, archive, move }}
      />
    </>
  );
}
function RecordList({
  title,
  kind,
  orderKind,
  table,
  items,
  label,
  begin,
  archive,
  move,
  extra,
}: any) {
  return (
    <section className="editor-section">
      <div className="section-heading">
        <h2>{title}</h2>
        <button onClick={() => begin(kind)}>Add</button>
      </div>
      {items.map((x: any, i: number) => (
        <article
          className={`editor-item ${x.archived_at ? "archived" : ""}`}
          key={x.id}
        >
          <strong>{label(x)}</strong>
          <div className="record-actions">
            <button onClick={() => begin(kind, x)}>Edit</button>
            {extra?.(x)}
            <button
              onClick={() => move(orderKind, items, i, -1)}
              disabled={i === 0}
              aria-label={`Move ${label(x)} up`}
            >
              ↑
            </button>
            <button
              onClick={() => move(orderKind, items, i, 1)}
              disabled={i === items.length - 1}
              aria-label={`Move ${label(x)} down`}
            >
              ↓
            </button>
            <button onClick={() => archive(table, x.id, !x.archived_at)}>
              {x.archived_at ? "Restore" : "Archive"}
            </button>
          </div>
        </article>
      ))}
    </section>
  );
}
function LibraryForm({ kind, draft, setDraft }: any) {
  const field = (name: string, label: string, type = "text") => (
    <label>
      {label}
      <input
        type={type}
        value={draft[name] ?? ""}
        onChange={(e) => setDraft({ ...draft, [name]: e.target.value })}
      />
    </label>
  );
  if (kind === "profile")
    return (
      <div className="form-grid">
        {field("name", "Name")}
        {field("phone", "Phone")}
        {field("email", "Email", "email")}
        {field("linkedin_label", "LinkedIn label")}
        {field("linkedin_url", "LinkedIn URL", "url")}
      </div>
    );
  if (kind === "summary")
    return (
      <div className="form-grid">
        {field("name", "Variant name")}
        <label className="full">
          Summary
          <textarea
            value={draft.body}
            onChange={(e) => setDraft({ ...draft, body: e.target.value })}
          />
        </label>
      </div>
    );
  if (kind === "interest")
    return <div className="form-grid">{field("body", "Interest")}</div>;
  if (kind === "bullet")
    return (
      <div className="form-grid">
        {field("variant_name", "Initial variant label")}
        <label className="full">
          Initial wording
          <textarea
            value={draft.body}
            onChange={(e) => setDraft({ ...draft, body: e.target.value })}
          />
        </label>
      </div>
    );
  if (kind === "variant")
    return (
      <div className="form-grid">
        {field("name", "Variant label")}
        <label className="full">
          Wording
          <textarea
            value={draft.body}
            onChange={(e) => setDraft({ ...draft, body: e.target.value })}
          />
        </label>
      </div>
    );
  if (kind === "custom-section")
    return (
      <div className="form-grid">
        {field("title", "Section title")}
        <label>
          Layout
          <select
            value={draft.layout}
            onChange={(e) => setDraft({ ...draft, layout: e.target.value })}
          >
            <option value="list">List</option>
            <option value="compact">Compact</option>
            <option value="dated">Dated</option>
            <option value="experience">Experience</option>
          </select>
        </label>
      </div>
    );
  if (kind === "custom-entry")
    return (
      <div className="form-grid">
        {field("primary_text", "Primary text")}
        {field("secondary_text", "Secondary text")}
        {field("location", "Location")}
        {field("date_label", "Date label")}
      </div>
    );
  if (kind === "tool-group")
    return <div className="form-grid">{field("name", "Group name")}</div>;
  if (kind === "tool")
    return (
      <div className="form-grid">
        {field("name", "Tool name")}
        <label>
          Group
          <select
            value={draft.group_id}
            onChange={(e) => setDraft({ ...draft, group_id: e.target.value })}
          >
            {draft.groups?.map?.((g: any) => (
              <option key={g.id} value={g.id}>
                {g.name}
              </option>
            ))}
          </select>
        </label>
      </div>
    );
  if (["project", "employment", "leadership"].includes(kind))
    return (
      <div className="form-grid">
        {kind === "project" ? (
          <>
            {field("name", "Project name")}
            {field("subtitle", "Subtitle or technologies")}
          </>
        ) : (
          <>
            {field("organization", "Organization")}
            {field(
              "title",
              kind === "leadership" ? "Leadership title" : "Job title",
            )}
          </>
        )}
        {field("location", "Location")}
        {field("start_year", "Start year", "number")}
        {field("start_month", "Start month", "number")}
        {field("end_year", "End year", "number")}
        {field("end_month", "End month", "number")}
        {field("date_label", "Display-date override")}
        <label className="choice">
          <input
            type="checkbox"
            checked={!!draft.is_current}
            onChange={(e) =>
              setDraft({ ...draft, is_current: e.target.checked })
            }
          />
          Current / ongoing
        </label>
        <div className="full read-only">
          <strong>Existing bullets</strong>
          {(draft.bullets || []).map((b: any, i: number) => (
            <div key={i}>{b.body || b}</div>
          ))}
        </div>
      </div>
    );
  return (
    <div className="form-grid">
      {field("institution", "Institution or university")}
      {field("college_school", "College or school")}
      {field("location", "Location")}
      {field("degree_type", "Degree type")}
      {field("degree_major", "Degree or major")}
      {field("graduation_year", "Graduation year", "number")}
      {field("graduation_month", "Graduation month (1-12)", "number")}
      {field("display_date", "Display-date override")}
    </div>
  );
}
function ToolGroupsEditor({ lib, begin, archive, move }: any) {
  return (
    <section className="editor-section">
      <div className="section-heading">
        <h2>Tool groups</h2>
        <button onClick={() => begin("tool-group")}>Add group</button>
      </div>
      {lib.tool_groups.map((g: any, gi: number) => (
        <article
          className={`editor-item ${g.archived_at ? "archived" : ""}`}
          key={g.id}
        >
          <div className="section-heading">
            <strong>{g.name}</strong>
            <span>
              <button onClick={() => begin("tool-group", g)}>Edit</button>
              <button
                onClick={() => move("tool-groups", lib.tool_groups, gi, -1)}
                disabled={gi === 0}
                aria-label={`Move ${g.name} up`}
              >
                ↑
              </button>
              <button
                onClick={() => move("tool-groups", lib.tool_groups, gi, 1)}
                disabled={gi === lib.tool_groups.length - 1}
                aria-label={`Move ${g.name} down`}
              >
                ↓
              </button>
              <button
                onClick={() => archive("tool_groups", g.id, !g.archived_at)}
              >
                {g.archived_at ? "Restore" : "Archive"}
              </button>
            </span>
          </div>
          <button
            disabled={!!g.archived_at}
            onClick={() => begin("tool", { group_id: g.id })}
          >
            Add tool
          </button>
          {g.items.map((t: any, ti: number) => (
            <div
              className={`nested-record ${t.archived_at ? "archived" : ""}`}
              key={t.id}
            >
              <span>{t.name}</span>
              <span>
                <button onClick={() => begin("tool", { ...t, group_id: g.id })}>
                  Edit / move
                </button>
                <button
                  onClick={() =>
                    move(`tool-groups/${g.id}/tools`, g.items, ti, -1)
                  }
                  disabled={ti === 0}
                >
                  ↑
                </button>
                <button
                  onClick={() =>
                    move(`tool-groups/${g.id}/tools`, g.items, ti, 1)
                  }
                  disabled={ti === g.items.length - 1}
                >
                  ↓
                </button>
                <button onClick={() => archive("tools", t.id, !t.archived_at)}>
                  {t.archived_at ? "Restore" : "Archive"}
                </button>
              </span>
            </div>
          ))}
        </article>
      ))}
    </section>
  );
}
function groupBullets(rows: any[]) {
  const m = new Map<string, any>();
  for (const r of rows || []) {
    if (!m.has(r.id))
      m.set(r.id, {
        id: r.id,
        parent_id: r.parent_id,
        sort_order: r.sort_order,
        archived_at: r.archived_at,
        variants: [],
      });
    if (r.variant_id)
      m.get(r.id).variants.push({
        id: r.variant_id,
        bullet_id: r.id,
        variant_name: r.variant_name,
        body: r.body,
        is_default: r.is_default,
        sort_order: r.variant_sort_order,
        archived_at: r.variant_archived_at,
      });
  }
  return [...m.values()];
}
function BulletsEditor({ item, lib, begin, mutation }: any) {
  const bullets = groupBullets(item.bullets);
  const parents = [
    ...lib.projects,
    ...lib.employment,
    ...lib.leadership,
  ].filter((x: any) => !x.archived_at);
  const reorder = (path: string, rows: any[], i: number, d: number) => {
    const a = [...rows],
      j = i + d;
    if (j < 0 || j >= a.length) return;
    [a[i], a[j]] = [a[j], a[i]];
    return mutation(() =>
      api(path, {
        method: "PUT",
        body: JSON.stringify({ ids: a.map((x) => x.id) }),
      }),
    );
  };
  return (
    <div className="bullet-editor">
      <button onClick={() => begin("bullet", { parent_id: item.id })}>
        Add bullet
      </button>
      {bullets.map((b: any, bi: number) => (
        <div
          className={`bullet-card ${b.archived_at ? "archived" : ""}`}
          key={b.id}
        >
          <div className="record-actions">
            <strong>Bullet {bi + 1}</strong>
            <button
              onClick={() =>
                reorder(
                  `/api/library/parents/${item.id}/bullets/order`,
                  bullets,
                  bi,
                  -1,
                )
              }
              disabled={bi === 0}
            >
              Move bullet up
            </button>
            <button
              onClick={() =>
                reorder(
                  `/api/library/parents/${item.id}/bullets/order`,
                  bullets,
                  bi,
                  1,
                )
              }
              disabled={bi === bullets.length - 1}
            >
              Move bullet down
            </button>
            <button
              onClick={() =>
                mutation(() =>
                  api(`/api/library/bullets/${b.id}/duplicate`, {
                    method: "POST",
                  }),
                )
              }
            >
              Duplicate bullet
            </button>
            <select
              aria-label="Move bullet to parent"
              value={item.id}
              onChange={(e) =>
                mutation(() =>
                  api(`/api/library/bullets/${b.id}/move`, {
                    method: "POST",
                    body: JSON.stringify({ parent_id: e.target.value }),
                  }),
                )
              }
            >
              {parents.map((p: any) => (
                <option key={p.id} value={p.id}>
                  {p.name || `${p.organization} — ${p.title}`}
                </option>
              ))}
            </select>
            <button
              onClick={() =>
                mutation(() =>
                  api(
                    `/api/library/bullets/${b.id}/${b.archived_at ? "restore" : "archive"}`,
                    {
                      method: "POST",
                      body: b.archived_at
                        ? JSON.stringify({ parent_id: item.id })
                        : undefined,
                    },
                  ),
                )
              }
            >
              {b.archived_at ? "Restore bullet" : "Archive bullet"}
            </button>
          </div>
          <button
            disabled={!!b.archived_at}
            onClick={() => begin("variant", { bullet_id: b.id })}
          >
            Add wording variant
          </button>
          {b.variants.map((v: any, vi: number) => (
            <div
              className={`variant-row ${v.archived_at ? "archived" : ""}`}
              key={v.id}
            >
              <span>
                {v.variant_name}
                {v.is_default ? " (Default)" : ""}: {v.body}
              </span>
              <div className="record-actions">
                <button onClick={() => begin("variant", v)}>
                  Edit variant
                </button>
                <button
                  onClick={() =>
                    reorder(
                      `/api/library/bullets/${b.id}/variants/order`,
                      b.variants,
                      vi,
                      -1,
                    )
                  }
                  disabled={vi === 0}
                >
                  Move variant up
                </button>
                <button
                  onClick={() =>
                    reorder(
                      `/api/library/bullets/${b.id}/variants/order`,
                      b.variants,
                      vi,
                      1,
                    )
                  }
                  disabled={vi === b.variants.length - 1}
                >
                  Move variant down
                </button>
                <button
                  onClick={() =>
                    mutation(() =>
                      api(`/api/library/variants/${v.id}/duplicate`, {
                        method: "POST",
                      }),
                    )
                  }
                >
                  Duplicate variant
                </button>
                <button
                  disabled={!!v.archived_at || v.is_default}
                  onClick={() =>
                    mutation(() =>
                      api(`/api/library/variants/${v.id}/default`, {
                        method: "POST",
                      }),
                    )
                  }
                >
                  Set default
                </button>
                <button
                  onClick={() => {
                    const replacement = v.is_default
                      ? b.variants.find(
                          (x: any) => !x.archived_at && x.id !== v.id,
                        )?.id
                      : null;
                    return mutation(() =>
                      api(
                        `/api/library/variants/${v.id}/${v.archived_at ? "restore" : "archive"}`,
                        {
                          method: "POST",
                          body: v.archived_at
                            ? undefined
                            : JSON.stringify({
                                replacement_variant_id: replacement || null,
                              }),
                        },
                      ),
                    );
                  }}
                >
                  {v.archived_at ? "Restore variant" : "Archive variant"}
                </button>
              </div>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}
const BUILTIN_SECTIONS = [
  ["summary", "Summary"],
  ["education", "Education"],
  ["tools", "Skills"],
  ["projects", "Projects"],
  ["work_experience", "Work Experience"],
  ["leadership", "Leadership"],
  ["personal_interests", "Personal Interests"],
];
const EDITOR_SECTION_ICONS: Record<
  string,
  Parameters<typeof AppIcon>[0]["name"]
> = {
  profile: "profile",
  summary: "document",
  education: "education",
  tools: "skills",
  projects: "projects",
  work_experience: "experience",
  leadership: "leadership",
  personal_interests: "interests",
};
const editorSectionIcon = (key: string) =>
  key.startsWith("custom:")
    ? "custom-sections"
    : EDITOR_SECTION_ICONS[key] || "custom-sections";
function AddBulletButton() {
  return (
    <span className="tooltip-wrap">
      <button
        type="button"
        className="add-bullet-inline"
        aria-disabled="true"
        aria-describedby="add-bullet-soon"
        onClick={(e) => e.preventDefault()}
      >
        + Add Bullet
      </button>
      <span id="add-bullet-soon" role="tooltip">
        Adding bullets is coming soon.
      </span>
    </span>
  );
}
function ModalShell({ title, close, children }: any) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const shell = document.querySelector<HTMLElement>(".editing-shell");
    shell?.setAttribute("inert", "");
    ref.current?.removeAttribute("inert");
    ref.current
      ?.querySelector<HTMLElement>("button,input,select,textarea")
      ?.focus();
    const key = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key !== "Tab" || !ref.current) return;
      const all = [
        ...ref.current.querySelectorAll<HTMLElement>(
          "button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled])",
        ),
      ];
      if (!all.length) return;
      if (e.shiftKey && document.activeElement === all[0]) {
        e.preventDefault();
        all.at(-1)?.focus();
      } else if (!e.shiftKey && document.activeElement === all.at(-1)) {
        e.preventDefault();
        all[0].focus();
      }
    };
    addEventListener("keydown", key);
    return () => {
      removeEventListener("keydown", key);
      shell?.removeAttribute("inert");
      previous?.focus();
    };
  }, []);
  return (
    <div className="bullet-picker-backdrop">
      <div
        className="modal-shell"
        role="dialog"
        aria-modal="true"
        aria-labelledby="entry-dialog-title"
        ref={ref}
      >
        <div className="section-heading">
          <h2 id="entry-dialog-title">{title}</h2>
          <button aria-label={`Close ${title}`} onClick={close}>
            ×
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}
const ENTRY_LABELS: any = {
  projects: "Project",
  work_experience: "Experience",
  education: "Education",
  tool_groups: "Skill Group",
  leadership: "Leadership",
  personal_interests: "Interest",
};
function AddEntryDialog({
  comp,
  section,
  items,
  includedIds,
  close,
  saved,
  fail,
}: any) {
  const custom = section.startsWith("custom:");
  const [tab, setPickerTab] = useState<"library" | "create">(
    custom ? "create" : "library",
  );
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState<any>(null);
  const [draft, setDraft] = useState<any>({});
  const [busy, setBusy] = useState(false);
  const label = custom ? "Entry" : ENTRY_LABELS[section];
  const available = items
    .filter(
      (x: any) =>
        !x.archived_at &&
        !includedIds.includes(String(x.id)) &&
        JSON.stringify(x).toLowerCase().includes(q.toLowerCase()),
    )
    .slice(0, 5);
  const add = async () => {
    setBusy(true);
    try {
      if (tab === "library") {
        if (!selected) return;
        const endpoint =
          section === "personal_interests"
            ? "interests"
            : section === "tool_groups"
              ? "tool-groups"
              : section === "education"
                ? "education"
                : `historical/${section}`;
        saved(
          await api(`/api/compositions/${comp.id}/${endpoint}`, {
            method: "PUT",
            body: JSON.stringify({
              revision: comp.revision,
              item_id: selected.id,
              included: true,
            }),
          }),
          selected.id,
        );
      } else {
        saved(
          await api(`/api/compositions/${comp.id}/entries/create`, {
            method: "POST",
            body: JSON.stringify({
              revision: comp.revision,
              section,
              fields: draft,
            }),
          }),
        );
      }
    } catch (e) {
      fail(e);
    } finally {
      setBusy(false);
    }
  };
  return (
    <ModalShell title={`Add ${label}`} close={close}>
      {!custom && (
        <div className="picker-tabs" role="tablist">
          <button
            role="tab"
            aria-selected={tab === "library"}
            onClick={() => setPickerTab("library")}
          >
            Choose from Library
          </button>
          <button
            role="tab"
            aria-selected={tab === "create"}
            onClick={() => setPickerTab("create")}
          >
            Create New
          </button>
        </div>
      )}
      {tab === "library" ? (
        <>
          <input
            aria-label={`Search ${label}`}
            placeholder="Search library…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
          <div className="entry-picker-grid">
            <div className="entry-picker-results">
              {available.map((x: any) => (
                <button
                  className="entry-picker-result"
                  aria-pressed={selected?.id === x.id}
                  key={x.id}
                  onClick={() => setSelected(x)}
                >
                  <strong>
                    {x.name || x.organization || x.institution || x.body}
                  </strong>
                  <small>
                    {x.title || x.subtitle || x.degree_major || ""} ·{" "}
                    {
                      groupBullets(x.bullets || []).filter(
                        (b: any) => !b.archived_at,
                      ).length
                    }{" "}
                    bullets
                  </small>
                </button>
              ))}
              <small>
                Showing 1–{available.length} of {available.length} items
              </small>
            </div>
            <div className="entry-picker-details">
              {selected ? (
                <pre>{JSON.stringify(selected, null, 2)}</pre>
              ) : (
                <p>Select an entry to review details and bullets.</p>
              )}
            </div>
          </div>
        </>
      ) : (
        <div className="form-grid">
          <label className="full">
            Primary text
            <input
              value={
                draft.name ||
                draft.organization ||
                draft.institution ||
                draft.body ||
                ""
              }
              onChange={(e) =>
                setDraft(
                  section === "projects"
                    ? { ...draft, name: e.target.value }
                    : section === "education"
                      ? { ...draft, institution: e.target.value }
                      : section === "personal_interests"
                        ? { ...draft, body: e.target.value }
                        : { ...draft, organization: e.target.value },
                )
              }
            />
          </label>
          {["projects", "work_experience", "leadership"].includes(section) && (<>
            <MonthYearField label="Start" year={draft.start_year} month={draft.start_month} onChange={({year,month})=>setDraft({...draft,start_year:year,start_month:month})} />
            <MonthYearField label="End" year={draft.end_year} month={draft.end_month} disabled={!!draft.is_current} onChange={({year,month})=>setDraft({...draft,end_year:year,end_month:month})} />
            <label className="choice"><input type="checkbox" checked={!!draft.is_current} onChange={e=>setDraft({...draft,is_current:e.target.checked,end_year:null,end_month:null})} />Current</label>
          </>)}
          {section === "education" && <MonthYearField label="Graduation" year={draft.graduation_year} month={draft.graduation_month} onChange={({year,month})=>setDraft({...draft,graduation_year:year,graduation_month:month})} />}
          {["work_experience", "leadership"].includes(section) && (
            <label>
              Title
              <input
                value={draft.title || ""}
                onChange={(e) => setDraft({ ...draft, title: e.target.value })}
              />
            </label>
          )}
        </div>
      )}
      <div className="form-actions">
        <button onClick={close}>Cancel</button>
        <button
          className="primary"
          disabled={busy || (tab === "library" && !selected)}
          onClick={add}
        >
          Add to Resume
        </button>
      </div>
    </ModalShell>
  );
}
function chronologicalKey(x: any) {
  const structured = !!(x.start_year || x.end_year || x.is_current);
  if (!structured) return [1, 0, 0, x.sort_order || 0, String(x.id)];
  const end = x.is_current
      ? 999912
      : (x.end_year || 0) * 100 + (x.end_month || 12),
    start = (x.start_year || 0) * 100 + (x.start_month || 1);
  return [
    0,
    x.is_current ? -1 : 0,
    -end,
    -start,
    x.sort_order || 0,
    String(x.id),
  ];
}
function SectionsPanel({
  comp,
  lib,
  setComp,
  setStatus,
  setError,
  collapsed,
  setCollapsed,
  begin,
  saveCompositionPreferences,
  chooseSummary,
  chooseInterest,
  chooseLibraryItem,
}: any) {
  const [compositionItems, setCompositionItems] = useState<any[]>([]),
    [placements, setPlacements] = useState<any[]>([]),
    [entryExpanded, setEntryExpanded] = useState<Record<string, boolean>>(
      () => {
        try {
          return JSON.parse(
            localStorage.getItem(`resume-engine-entry-expansion`) || "{}",
          );
        } catch {
          return {};
        }
      },
    ),
    [entryDialog, setEntryDialog] = useState<any>(null),
    [menu, setMenu] = useState<string | null>(null),
    [announcement, setAnnouncement] = useState("");
  const reload = () =>
    Promise.all([
      api<any[]>(`/api/compositions/${comp.id}/items`),
      api<any[]>(`/api/compositions/${comp.id}/bullet-placements`),
    ])
      .then(([i, b]) => {
        setCompositionItems(i);
        setPlacements(b);
      })
      .catch((e: any) => setError(e.message));
  useEffect(() => {
    reload();
  }, [comp.id, comp.revision]);
  useEffect(
    () =>
      localStorage.setItem(
        "resume-engine-entry-expansion",
        JSON.stringify(entryExpanded),
      ),
    [entryExpanded],
  );
  const clean = (x: string) => (x.startsWith("hidden:") ? x.slice(7) : x),
    source = comp.resume.section_order || [],
    custom = lib.custom_sections.map((x: any) => [
      `custom:${x.id}`,
      x.title,
      x,
    ]);
  const order = [
    ...source,
    ...custom
      .map((x: any) => x[0])
      .filter((x: string) => !source.map(clean).includes(x)),
  ];
  const rows = order
    .map((stored: string) => {
      const key = clean(stored),
        b = BUILTIN_SECTIONS.find((x) => x[0] === key),
        c = custom.find((x: any) => x[0] === key),
        base = b ? [b[0], b[1], null] : c;
      return base ? [...base, !stored.startsWith("hidden:")] : null;
    })
    .filter(Boolean) as any[];
  const save = async (next: any[]) => {
    try {
      setStatus("Saving…");
      const section_order = next.map((x) => (x[3] ? x[0] : `hidden:${x[0]}`));
      setComp(
        await api(`/api/compositions/${comp.id}/sections`, {
          method: "PUT",
          body: JSON.stringify({
            revision: comp.revision,
            section_order,
            interest_layout: comp.resume.interest_layout || "compact",
            included_builtin: next
              .filter((x) => !x[0].startsWith("custom:") && x[3])
              .map((x) => x[0]),
            included_custom: next
              .filter((x) => x[0].startsWith("custom:") && x[3])
              .map((x) => x[0].slice(7)),
          }),
        }),
      );
      setStatus("Saved");
    } catch (e: any) {
      setError(e.message);
      setStatus(e.status === 409 ? "Conflict" : "Save failed");
    }
  };
  const moveSection = (i: number, d: number) => {
    const t = i + d;
    if (t < 0 || t >= rows.length) return;
    const n = rows.map((x) => [...x]);
    [n[i], n[t]] = [n[t], n[i]];
    save(n);
    setAnnouncement(
      `${rows[i][1]} moved to position ${t + 1} of ${rows.length}.`,
    );
  };
  const sources: any = {
    education: lib.education,
    tool_groups: lib.tool_groups,
    projects: lib.projects,
    work_experience: lib.employment,
    leadership: lib.leadership,
    personal_interests: lib.interests,
  };
  const sectionEntries = (key: string) => {
    let a = compositionItems
      .filter((x) => x.section === key)
      .sort((a, b) => a.sort_order - b.sort_order)
      .map((x) =>
        (sources[key] || []).find(
          (r: any) => String(r.id) === String(x.item_id),
        ),
      )
      .filter(Boolean);
    if (
      (comp.section_sort_modes?.[key] || "automatic") === "automatic" &&
      ["projects", "work_experience", "leadership"].includes(key)
    )
      a = [...a].sort((a, b) => {
        const left = chronologicalKey(a), right = chronologicalKey(b);
        for (let i = 0; i < Math.max(left.length, right.length); i++) {
          if (left[i] < right[i]) return -1;
          if (left[i] > right[i]) return 1;
        }
        return 0;
      });
    return a;
  };
  const reorder = async (key: string, items: any[], i: number, d: number) => {
    const t = i + d;
    if (t < 0 || t >= items.length) return;
    const ids = items.map((x) => x.id);
    [ids[i], ids[t]] = [ids[t], ids[i]];
    try {
      setComp(
        await api(`/api/compositions/${comp.id}/items/order`, {
          method: "PUT",
          body: JSON.stringify({ revision: comp.revision, section: key, ids }),
        }),
      );
      setAnnouncement(
        `${ENTRY_LABELS[key]} moved to position ${t + 1} of ${items.length}.`,
      );
    } catch (e: any) {
      setError(e.message);
    }
  };
  const card = (key: string, x: any, i: number, items: any[]) => {
    const id = String(x.id),
      expanded = entryExpanded[id] ?? i === 0,
      bullets = placements
        .filter((b) => String(b.destination_parent_id) === id)
        .sort((a, b) => a.sort_order - b.sort_order),
      title = x.organization || x.name || x.institution || x.body,
      subtitle = x.title || x.subtitle || x.degree_major || x.date_label || "",
      manual = (comp.section_sort_modes?.[key] || "automatic") === "manual";
    return (
      <article className="entry-card" key={id}>
        <div className="entry-card-header">
          <button className="item-drag-handle" aria-label={`Drag ${title}`}>
            ⠿
          </button>
          <span className="section-icon">
            <AppIcon name={editorSectionIcon(key)} />
          </span>
          <div>
            <strong>{title}</strong>
            <div className="entry-meta">
              <span>{subtitle}</span>
              <span>{x.location}</span>
              <span>{x.date_label || x.display_date}</span>
            </div>
          </div>
          <span className="entry-menu-wrap">
            <button
              aria-label={`Actions for ${title}`}
              onClick={() => setMenu(menu === id ? null : id)}
            >
              ⋮
            </button>
            {menu === id && (
              <span className="entry-menu" role="menu">
                <span className="tooltip-wrap">
                  <button role="menuitem" aria-disabled="true" aria-describedby={`edit-library-soon-${id}`} onClick={(event) => event.preventDefault()}>
                    Edit in Library
                  </button>
                  <span id={`edit-library-soon-${id}`} role="tooltip">Editing in the Library from the editor is coming soon.</span>
                </span>
                <button
                  role="menuitem"
                  disabled={!manual || i === 0}
                  title={
                    !manual ? "Choose Manual order to move entries." : undefined
                  }
                  onClick={() => reorder(key, items, i, -1)}
                >
                  Move up
                </button>
                <button
                  role="menuitem"
                  disabled={!manual || i === items.length - 1}
                  onClick={() => reorder(key, items, i, 1)}
                >
                  Move down
                </button>
                <button
                  role="menuitem"
                  onClick={() =>
                    key === "personal_interests"
                      ? chooseInterest(x, false)
                      : chooseLibraryItem(key, x, false)
                  }
                >
                  Remove from this resume
                </button>
              </span>
            )}
          </span>
          <button
            className="section-chevron"
            aria-expanded={expanded}
            onClick={() =>
              setEntryExpanded({ ...entryExpanded, [id]: !expanded })
            }
          >
            ↓
          </button>
        </div>
        {expanded && (
          <div className="entry-card-body">
            {key === "tool_groups" && (
              <div className="tool-chips">
                {(x.items || []).map((t: any) => (
                  <span className="tool-chip" key={t.id}>
                    {t.name}
                  </span>
                ))}
              </div>
            )}
            <h4>Bullet Points</h4>
            <div className="bullet-list">
              {bullets.map((b: any, bi: number) => (
                <div className="bullet-row" key={b.id}>
                  <button
                    className="item-drag-handle"
                    aria-label={`Drag bullet ${bi + 1}`}
                  >
                    ⠿
                  </button>
                  <span>
                    {b.wording_snapshot}
                    {b.active_variant_count > 1 && (
                      <small> · {b.variant_name}</small>
                    )}
                    {b.usage_status !== "current" && (
                      <span className="bullet-status">{b.usage_status}</span>
                    )}
                  </span>
                  <button
                    aria-label="Bullet actions"
                    onClick={async () => {
                      if (confirm("Remove this bullet from this resume?")) {
                        try {
                          setComp(
                            await api(
                              `/api/compositions/${comp.id}/bullet-placements/${b.id}?revision=${comp.revision}`,
                              { method: "DELETE" },
                            ),
                          );
                        } catch (e: any) {
                          setError(e.message);
                        }
                      }
                    }}
                  >
                    ⋮
                  </button>
                </div>
              ))}
            </div>
            <AddBulletButton />
          </div>
        )}
      </article>
    );
  };
  const content = (key: string) => {
    if (key === "summary")
      return (
        <div className="entry-card">
          <label>
            Summary variant
            <select
              value={comp.summary_variant_id || ""}
              onChange={(e) => chooseSummary(e.target.value)}
            >
              <option value="">No summary</option>
              {lib.summary_variants
                .filter((x: any) => !x.archived_at)
                .map((x: any) => (
                  <option key={x.id} value={x.id}>
                    {x.name}
                  </option>
                ))}
            </select>
          </label>
        </div>
      );
    if (key.startsWith("custom:")) {
      const sec = lib.custom_sections.find(
        (x: any) => `custom:${x.id}` === key,
      );
      return (
        <div className="entry-list">
          {sec?.entries.map((x: any, i: number) =>
            card(key, x, i, sec.entries),
          )}
          <button
            className="add-entry-button"
            onClick={() => setEntryDialog({ section: key, items: [] })}
          >
            + Add Entry
          </button>
        </div>
      );
    }
    const items = sectionEntries(key);
    return (
      <div className="entry-list">
        {["projects", "work_experience", "leadership"].includes(key) && (
          <label className="order-mode">
            Order:
            <select
              value={comp.section_sort_modes?.[key] || "automatic"}
              onChange={(e) =>
                saveCompositionPreferences({
                  preferred_page_length: comp.preferred_page_length || 1,
                  date_format: comp.date_format || "long",
                  section_sort_modes: {
                    ...comp.section_sort_modes,
                    [key]: e.target.value,
                  },
                })
              }
            >
              <option value="automatic">By date</option>
              <option value="manual">Manual</option>
            </select>
          </label>
        )}
        {items.map((x: any, i: number) => card(key, x, i, items))}
        <button
          className="add-entry-button"
          onClick={() =>
            setEntryDialog({
              section: key,
              items: sources[key] || [],
              includedIds: items.map((x: any) => String(x.id)),
            })
          }
        >
          + Add {ENTRY_LABELS[key]}
        </button>
      </div>
    );
  };
  return (
    <section className="resume-sections" aria-labelledby="sections-title">
      <div className="sections-heading">
        <h2 id="sections-title">
          Sections{" "}
          <span className="tooltip-wrap">
            <button aria-describedby="sections-help">?</button>
            <span id="sections-help" role="tooltip">
              Remove entries from this resume from each card menu. Archive
              reusable records in Library.
            </span>
          </span>
        </h2>
        <span className="tooltip-wrap">
          <button aria-disabled="true" aria-describedby="add-section-soon" onClick={(event) => event.preventDefault()}>+ Add Section</button>
          <span id="add-section-soon" role="tooltip">Editing in the Library from the editor is coming soon.</span>
        </span>
      </div>
      <div className="sr-only" aria-live="polite">
        {announcement}
      </div>
      <article className="section-card profile-section">
        <div className="section-card-header">
          <span className="section-icon">
            <AppIcon name="profile" />
          </span>
          <strong>Profile</strong>
          <button
            className="section-chevron"
            aria-expanded={!collapsed.includes("profile")}
            onClick={() =>
              setCollapsed(
                collapsed.includes("profile")
                  ? collapsed.filter((x: string) => x !== "profile")
                  : [...collapsed, "profile"],
              )
            }
          >
            ↓
          </button>
        </div>
      </article>
      {rows.map((r: any, i: number) => {
        const closed = collapsed.includes(r[0]);
        return (
          <article
            className={`section-card ${closed ? "collapsed" : "expanded"}`}
            key={r[0]}
          >
            <div className="section-card-header">
              <button
                className="drag-handle"
                aria-label={`Move ${r[1]}`}
                onKeyDown={(e) => {
                  if (e.key === "ArrowUp") moveSection(i, -1);
                  if (e.key === "ArrowDown") moveSection(i, 1);
                }}
              >
                ⠿
              </button>
              <span className="section-icon">
                <AppIcon name={editorSectionIcon(r[0])} />
              </span>
              <strong>{r[1]}</strong>
              <span className="item-count">
                {r[0] === "summary" ? "" : sectionEntries(r[0]).length || ""}
              </span>
              <label className="visibility-toggle">
                <input
                  type="checkbox"
                  role="switch"
                  aria-checked={r[3]}
                  checked={r[3]}
                  onChange={(e) => {
                    const n = rows.map((x) => [...x]);
                    n[i][3] = e.target.checked;
                    save(n);
                  }}
                />
                <span className="sr-only">
                  {r[3] ? "Hide" : "Show"} {r[1]}
                </span>
              </label>
              <button
                className="section-chevron"
                aria-expanded={!closed}
                onClick={() =>
                  setCollapsed(
                    closed
                      ? collapsed.filter((x: string) => x !== r[0])
                      : [...collapsed, r[0]],
                  )
                }
              >
                ↓
              </button>
            </div>
            {!closed && (
              <div className="section-card-body">{content(r[0])}</div>
            )}
          </article>
        );
      })}
      {entryDialog && (
        <AddEntryDialog
          comp={comp}
          {...entryDialog}
          close={() => setEntryDialog(null)}
          fail={(e: any) => setError(e.message)}
          saved={(next: any, id?: string) => {
            setComp(next);
            setEntryDialog(null);
            if (id) setEntryExpanded({ ...entryExpanded, [id]: true });
            reload();
          }}
        />
      )}
    </section>
  );
}
function CustomSectionsEditor({ lib, begin, mutation }: any) {
  const reorder = (sid: string, entries: any[], i: number, d: number) => {
    const n = [...entries],
      j = i + d;
    if (j < 0 || j >= n.length) return;
    [n[i], n[j]] = [n[j], n[i]];
    return mutation(() =>
      api(`/api/library/custom-sections/${sid}/entries/order`, {
        method: "PUT",
        body: JSON.stringify({ ids: n.map((x) => x.id) }),
      }),
    );
  };
  return (
    <section className="editor-section">
      <div className="section-heading">
        <h2>Custom sections</h2>
        <button onClick={() => begin("custom-section")}>Create section</button>
      </div>
      {lib.custom_sections.map((section: any) => (
        <article
          className={`editor-item ${section.archived_at ? "archived" : ""}`}
          key={section.id}
        >
          <div className="section-heading">
            <strong>
              {section.title} · {section.layout}
            </strong>
            <span>
              <button onClick={() => begin("custom-section", section)}>
                Edit title / layout
              </button>
              <button
                onClick={() =>
                  mutation(() =>
                    api(`/api/library/custom-sections/${section.id}/entries`, {
                      method: "PUT",
                      body: JSON.stringify({
                        ids: section.entries.map((x: any) => x.id),
                      }),
                    }),
                  )
                }
                hidden
              >
                Order
              </button>
              <button
                onClick={() =>
                  mutation(() =>
                    api(
                      `/api/library/custom-sections/${section.id}/${section.archived_at ? "restore" : "archive"}`.replace(
                        "/custom-sections/",
                        "/custom-sections/",
                      ),
                      { method: "POST" },
                    ),
                  )
                }
              >
                {section.archived_at ? "Restore section" : "Archive section"}
              </button>
            </span>
          </div>
          <button
            disabled={!!section.archived_at}
            onClick={() => begin("custom-entry", { section_id: section.id })}
          >
            Add entry
          </button>
          {section.entries.map((entry: any, i: number) => (
            <div
              className={`nested-record ${entry.archived_at ? "archived" : ""}`}
              key={entry.id}
            >
              <span>{entry.primary_text}</span>
              <span>
                <button
                  onClick={() =>
                    begin("custom-entry", { ...entry, section_id: section.id })
                  }
                >
                  Edit entry
                </button>
                <button
                  disabled={i === 0}
                  onClick={() => reorder(section.id, section.entries, i, -1)}
                >
                  ↑
                </button>
                <button
                  disabled={i === section.entries.length - 1}
                  onClick={() => reorder(section.id, section.entries, i, 1)}
                >
                  ↓
                </button>
                <button
                  onClick={() =>
                    mutation(() =>
                      api(
                        `/api/library/custom-entries/${entry.id}/${entry.archived_at ? "restore" : "archive"}`,
                        { method: "POST" },
                      ),
                    )
                  }
                >
                  {entry.archived_at ? "Restore entry" : "Archive entry"}
                </button>
              </span>
            </div>
          ))}
        </article>
      ))}
    </section>
  );
}
function LibrarySearch() {
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("active");
  const [rows, setRows] = useState<any[]>([]);
  const [offset, setOffset] = useState(0);
  const [busy, setBusy] = useState(false);
  const run = async (next = 0) => {
    setBusy(true);
    try {
      setRows(
        await api(
          `/api/library/search?q=${encodeURIComponent(q)}&status=${status}&limit=25&offset=${next}`,
        ),
      );
      setOffset(next);
    } finally {
      setBusy(false);
    }
  };
  return (
    <section className="editor-section search-panel">
      <h2>Search library</h2>
      <div className="search-row">
        <input
          aria-label="Search library"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && run(0)}
        />
        <select
          aria-label="Search status"
          value={status}
          onChange={(e) => setStatus(e.target.value)}
        >
          <option value="active">Active</option>
          <option value="archived">Archived</option>
          <option value="all">All</option>
        </select>
        <button onClick={() => run(0)}>Search</button>
      </div>
      {busy ? (
        <p>Searching…</p>
      ) : rows.length ? (
        <div aria-live="polite">
          {rows.map((r) => (
            <article
              className={`search-result ${r.archived ? "archived" : ""}`}
              key={`${r.type}:${r.id}`}
            >
              <strong>{r.label}</strong>
              <span>
                {r.type.replaceAll("_", " ")}
                {r.archived ? " · Archived" : ""}
              </span>
              {r.context && <small>{r.context}</small>}
              {r.tags?.length ? <small>Tags: {r.tags.join(", ")}</small> : null}
            </article>
          ))}
          <div className="search-pagination">
            <button
              disabled={offset === 0}
              onClick={() => run(Math.max(0, offset - 25))}
            >
              Previous
            </button>
            <button
              disabled={rows.length < 25}
              onClick={() => run(offset + 25)}
            >
              Next
            </button>
          </div>
        </div>
      ) : q ? (
        <p>No results</p>
      ) : (
        <p>Enter text to search all library content.</p>
      )}
    </section>
  );
}

function BulletPicker({ comp, target, replacement, close, saved, fail }: any) {
  const [tab, setPickerTab] = useState<"library" | "create">("library");
  const [q, setQ] = useState("");
  const [section, setSection] = useState("");
  const [rows, setRows] = useState<any[]>([]);
  const [selected, setSelected] = useState<any>(null);
  const [variant, setVariant] = useState("");
  const [body, setBody] = useState("");
  const [busy, setBusy] = useState(false);
  const dialog = useRef<HTMLDivElement>(null);
  const search = async () => {
    setBusy(true);
    try {
      setRows(
        await api(
          `/api/library/bullet-picker?q=${encodeURIComponent(q)}&section=${encodeURIComponent(section)}&limit=25&offset=0`,
        ),
      );
    } catch (e) {
      fail(e);
    } finally {
      setBusy(false);
    }
  };
  useEffect(() => {
    search();
    requestAnimationFrame(() =>
      dialog.current
        ?.querySelector<HTMLElement>("button,input,select")
        ?.focus(),
    );
  }, []);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const shell = document.querySelector<HTMLElement>(".editing-shell");
    shell?.setAttribute("inert", "");
    dialog.current?.removeAttribute("inert");
    const fn = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        close();
        return;
      }
      if (e.key !== "Tab" || !dialog.current) return;
      const focusable = [
        ...dialog.current.querySelectorAll<HTMLElement>(
          'button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
        ),
      ];
      if (!focusable.length) return;
      const first = focusable[0],
        last = focusable[focusable.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };
    addEventListener("keydown", fn);
    return () => {
      removeEventListener("keydown", fn);
      shell?.removeAttribute("inert");
      previous?.focus();
    };
  }, []);
  const choose = (row: any) => {
    setSelected(row);
    setVariant(
      row.variants?.find((x: any) => x.is_default)?.id ||
        row.variants?.[0]?.id ||
        "",
    );
  };
  const submit = async () => {
    setBusy(true);
    try {
      const url = replacement
        ? `/api/compositions/${comp.id}/bullet-placements/${replacement.id}`
        : tab === "create"
          ? `/api/compositions/${comp.id}/bullet-placements/create`
          : `/api/compositions/${comp.id}/bullet-placements`;
      const payload = replacement
        ? {
            revision: comp.revision,
            bullet_id: selected.id,
            variant_id: variant,
          }
        : tab === "create"
          ? {
              revision: comp.revision,
              body,
              variant_name: "Default",
              library_section: section || "experience",
              parent_context: target.label || "",
              ...target,
            }
          : {
              revision: comp.revision,
              bullet_id: selected.id,
              variant_id: variant,
              ...target,
            };
      saved(
        await api(url, {
          method: replacement ? "PUT" : "POST",
          body: JSON.stringify(payload),
        }),
      );
    } catch (e) {
      fail(e);
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="bullet-picker-backdrop" role="presentation">
      <div
        className="bullet-picker"
        role="dialog"
        aria-modal="true"
        aria-labelledby="bullet-picker-title"
        ref={dialog}
      >
        <div className="section-heading">
          <div>
            <h2 id="bullet-picker-title">
              {replacement ? "Replace Bullet" : "Add Bullet"}
            </h2>
            <p>{target.label}</p>
          </div>
          <button aria-label="Close Add Bullet" onClick={close}>
            ×
          </button>
        </div>
        {replacement && (
          <div className="replacement-banner" role="status">
            The current bullet remains in place until replacement succeeds.
          </div>
        )}
        <div className="picker-tabs" role="tablist">
          <button
            role="tab"
            aria-selected={tab === "library"}
            onClick={() => setPickerTab("library")}
          >
            Choose From Library
          </button>
          <button
            role="tab"
            aria-selected={tab === "create"}
            onClick={() => setPickerTab("create")}
          >
            Create New
          </button>
        </div>
        {tab === "library" ? (
          <>
            <div className="search-row">
              <input
                aria-label="Search active Library bullets"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && search()}
              />
              <select
                aria-label="Section filter"
                value={section}
                onChange={(e) => setSection(e.target.value)}
              >
                <option value="">All Sections</option>
                {[
                  "experience",
                  "projects",
                  "education",
                  "leadership",
                  "skills",
                  "interests",
                  "custom",
                ].map((x) => (
                  <option key={x}>{x}</option>
                ))}
              </select>
              <button onClick={search}>Search</button>
            </div>
            <div className="picker-grid" aria-busy={busy}>
              <div className="picker-results">
                {busy ? (
                  <p>Loading…</p>
                ) : rows.length ? (
                  rows.map((r) => (
                    <button
                      className={
                        selected?.id === r.id
                          ? "picker-result selected"
                          : "picker-result"
                      }
                      aria-pressed={selected?.id === r.id}
                      key={r.id}
                      onClick={() => choose(r)}
                    >
                      <strong>
                        {r.variants?.find((x: any) => x.is_default)?.body ||
                          r.variants?.[0]?.body}
                      </strong>
                      <small>
                        {r.section} · {r.variant_count} variants
                      </small>
                    </button>
                  ))
                ) : (
                  <p>No active bullets found.</p>
                )}
              </div>
              <div className="picker-details">
                {selected ? (
                  <>
                    <h3>Bullet Details</h3>
                    <p>{selected.parent_context || "No parent context"}</p>
                    <fieldset>
                      <legend>Variants</legend>
                      {selected.variants.map((v: any) => (
                        <label className="choice" key={v.id}>
                          <input
                            type="radio"
                            name="picker-variant"
                            value={v.id}
                            checked={variant === v.id}
                            onChange={() => setVariant(v.id)}
                          />
                          {v.body}
                          {v.is_default ? " (Default)" : ""}
                        </label>
                      ))}
                    </fieldset>
                  </>
                ) : (
                  <p>Select a bullet to review variants.</p>
                )}
              </div>
            </div>
          </>
        ) : (
          <label className="full">
            Bullet text
            <textarea value={body} onChange={(e) => setBody(e.target.value)} />
          </label>
        )}
        <div className="form-actions">
          <button onClick={close}>Cancel</button>
          <button
            className="primary"
            disabled={
              busy || (tab === "library" ? !selected || !variant : !body.trim())
            }
            onClick={submit}
          >
            {replacement ? "Replace Bullet" : "Use This Bullet"}
          </button>
        </div>
      </div>
    </div>
  );
}

function History({
  comp,
  reload,
  preview,
  clearPreview,
}: {
  comp: Comp;
  reload: () => Promise<any>;
  preview: (x: any) => void;
  clearPreview: () => void;
}) {
  const [rows, setRows] = useState<any[]>([]);
  useEffect(() => {
    api<any[]>(`/api/compositions/${comp.id}/revisions`).then(setRows);
  }, [comp.id, comp.revision]);
  return (
    <section>
      <h2>Revision history</h2>
      {rows.map((r) => (
        <article className="editor-item" key={r.id}>
          <strong>Revision {r.revision}</strong>
          <small>
            {new Date(r.created_at).toLocaleString()} · {r.source}
          </small>
          <button
            onClick={async () =>
              preview(
                await api(`/api/compositions/${comp.id}/revisions/${r.id}`),
              )
            }
          >
            Preview revision
          </button>
          <button
            onClick={async () => {
              await api(
                `/api/compositions/${comp.id}/revisions/${r.id}/restore`,
                {
                  method: "POST",
                  body: JSON.stringify({ revision: comp.revision }),
                },
              );
              await reload();
              clearPreview();
            }}
          >
            Restore as new revision
          </button>
        </article>
      ))}
    </section>
  );
}

