# Verified Baseline Findings

The attached review bundle explicitly shows:

- `App.tsx` imports `promptDialog`, retains `Save details`, renders both a large and compact fit indicator, has inactive Add Bullet UI, retains `chooseBulletVariant`, and does not consume `resume-engine-usage-target`.
- `StandaloneLibrary.tsx` uses `promptDialog` for bulk tags, section movement, and variant editing.
- `ConfirmDialog.tsx` exports `promptDialog`.
- `phase2j_repository.py` uses `_rebuild_resume` and positional mapping; `create_and_place` inserts a bullet with `parent_id=NULL`.
- Placement insertion does not verify that the destination is included in the composition and does not implement the complete same-section rule.
- `editing_repository.py` contains `select_bullet_variant` and malformed `RETURNING *` archive SQL.
- `phase2m_repository.py` calls `preprocess_resume(resume)` without passing composition sort modes and date format.
- The current schema/template do not fully render placed bullets for education, skill groups, ID-matched interests, and custom entries.
- `LibraryParentWrite` currently permits only `content_item`.
- The project tree contains migrations through 013 and no Phase 3d source/test files yet.
