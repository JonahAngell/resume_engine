# Phase 3d Implementation Contract

## Goal
Deliver one shared Library picker for add, replace, and wording changes across every resume section. Resume bullet wording is populated only from placement snapshots. Every placement mutation supports undo and redo. Editing Library wording never silently changes an existing placement.

## Authoritative baseline
- Commit: `ec4390283031efe2aa4a9cf190c74f9bd8b2a220`
- Branch: `main`
- Version: `v0.1.34`
- Existing migrations remain unchanged; add migration 014.
- Preserve owner scoping, optimistic revisions, default-deny OPA, and the single resume template.

## Required sequence
1. Finish Phase 3c gaps: remove promptDialog flows, Save details, and the large fit block; wire Home dialogs and Revision History.
2. Add additive migration 014 for five mutually exclusive parent columns, computed parent type, same-section checks, ownership checks, indexes, and deterministic backfill.
3. Replace positional resume rebuilding with `apply_placements`, locating entries by ID and clearing included entries with no placements.
4. Create/delete default placements when entries are included/removed.
5. Enforce duplicate 409, destination 404, section mismatch 422, and uniqueness-to-409 conversion.
6. Extend restore, archive-if-unused, positional insert, usage rows, picker search, unassigned, and bulk-parent routes.
7. Extend resume schemas and template for education, skill group, interest Lines layout, and custom-entry bullets.
8. Build shared `LibraryPicker.tsx`, `BulletRow.tsx`, and `AssignParentDialog.tsx`; add wide ModalShell.
9. Record all placement commands in EditorHistory with exact wording and sort position restoration.
10. Add usage deep-link handling, shared picker/Library detail components, responsive mobile steps, and accessibility behavior.
11. Add Phase 3d contract, integration, rendering, and browser tests; update PROJECT_CONTEXT.md.

## Protected behavior
- Server derives current-user ownership; no client user ID.
- Stale revisions continue returning 409 and invoke existing conflict recovery.
- Existing migrations 001-013 are not edited.
- Existing render payloads remain readable.
- No secrets, populated `.env`, dependency changes, or unrelated refactors.
- `backend/app/templates/resume.html` remains the preview/PDF template.

## Deliverable definition
A production update ZIP must contain complete modified/new files only, preserve paths, exclude unchanged files and secrets, and include actual validation results. `SaveCoordinator.ts` is excluded and may be deleted only after confirming no imports.
