# Validation Plan

## Prerequisites
- Working repository at commit `ec4390283031efe2aa4a9cf190c74f9bd8b2a220`
- Node and Python dependencies installed from lock/requirements files
- Disposable PostgreSQL database in `TEST_DATABASE_URL` with schema create/drop permission
- Running application at Playwright base URL for browser tests

## Baseline before changes
```bash
python -m pytest -q
npm run format:check
npm run test:tooling
npm run test:version
npm --prefix frontend run build
npm run test:browser
```

## Phase validation
```bash
python -m pytest -q tests/test_phase3d_contract.py tests/test_phase3a_contract.py tests/test_phase3b_contract.py tests/test_phase3c_contract.py tests/test_phase2j_contract.py tests/test_render_api.py
python -m pytest -q tests/test_phase3d_integration.py tests/test_phase2j_integration.py
npm run format:check
npm run test:tooling
npm run test:version
npm --prefix frontend run build
npm run test:browser
```

No command results are claimed by this handoff package.
